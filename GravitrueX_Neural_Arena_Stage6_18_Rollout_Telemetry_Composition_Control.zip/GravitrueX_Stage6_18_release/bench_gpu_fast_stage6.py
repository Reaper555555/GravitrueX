# -*- coding: utf-8 -*-
"""Stage 6 CUDA microbenchmark for GravitrueX's optimized tensor physics.

Compares eager decision dispatch against replaying a captured CUDA Graph for each
arena batch size. Graph capture/warmup is excluded from the steady-state loop time
and reported separately. It also runs a small full-rollout finite-value smoke test.
No training updates or checkpoint writes are performed.

Example (Windows venv):
  .venv\\Scripts\\python.exe bench_gpu_fast_stage6.py
  .venv\\Scripts\\python.exe bench_gpu_fast_stage6.py --arenas 128,256,512 --repeats 3
"""
from __future__ import annotations
import argparse
import datetime as dt
import gc
import os
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import gravitruex_ai as G


def make_policy(torch, width: int, depth: int, weights_path: Path | None):
    policy = G.ActorCritic(seed=8123, width=width, depth=depth, device_mode="cpu")
    loaded = False
    if weights_path and weights_path.exists():
        loaded = bool(policy.load(weights_path))
    return policy, loaded


def tensor_finite(torch, tensor) -> bool:
    return bool(torch.isfinite(tensor).all().item())


def select_weights(width: int, depth: int, explicit: str | None = None) -> Path | None:
    """Prefer an explicit checkpoint, otherwise the newest compatible model checkpoint.

    This matters when the user trains a named model such as TAC_1x1 instead of `main`.
    The benchmark only reads weights; it never modifies or saves them.
    """
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Requested benchmark checkpoint does not exist: {path}")
        w, d = G.checkpoint_architecture(path)
        if (w, d) != (width, depth):
            raise ValueError(f"Checkpoint profile {w}x{d} does not match benchmark {width}x{depth}: {path}")
        return path
    candidates = []
    try:
        for path in G.MODEL_ROOT.glob("*/weights_*_latest.npz"):
            try:
                if G.checkpoint_architecture(path) == (width, depth):
                    candidates.append(path)
            except Exception:
                continue
    except Exception:
        pass
    if candidates:
        return max(candidates, key=lambda p: p.stat().st_mtime)
    default_path = G.model_weights_path(G.DEFAULT_MODEL_ID)
    if default_path.exists() and G.checkpoint_architecture(default_path) == (width, depth):
        return default_path
    return None


def measure_variant(torch, batch_cls, arenas: int, decisions: int, width: int,
                    depth: int, graph_enabled: bool, repeat: int,
                    max_record_budget: int = 0, weights_path: Path | None = None) -> dict:
    policy, weights_loaded = make_policy(torch, width, depth, weights_path)
    kwargs = dict(
        engine=G, policy=policy, count=arenas, blue_n=1, red_n=1,
        random_compositions=False, opponent_mode="heuristic",
        max_decisions=decisions, device="cuda", seed=15000 + arenas * 31 + repeat,
        use_cuda_graph=graph_enabled,
    )
    if "max_records" in __import__("inspect").signature(batch_cls.__init__).parameters and max_record_budget > 0:
        kwargs["max_records"] = max_record_budget
    batch = batch_cls(**kwargs)
    torch.cuda.synchronize()

    capture_wall = 0.0
    graph = None
    if graph_enabled:
        cap_start = time.perf_counter()
        graph = batch._build_cuda_graph()
        torch.cuda.synchronize()
        capture_wall = time.perf_counter() - cap_start
        if graph is None:
            raise RuntimeError("CUDA Graph capture returned None; root cause: " + str(getattr(batch, "last_cuda_graph_error", None) or "not recorded"))
    else:
        # Same output buffers / step body as graph mode, but run eagerly.
        batch._alloc_graph_buffers()
        snap = batch._snapshot_state()
        for _ in range(3):
            batch._step_into_buffers()
        torch.cuda.synchronize()
        batch._restore_state(snap)

    # Short steady-state decision loop. The graph body and eager body are the same
    # _step_into_buffers function; only the dispatch mechanism differs.
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    start_event = torch.cuda.Event(enable_timing=True)
    end_event = torch.cuda.Event(enable_timing=True)
    start_wall = time.perf_counter()
    start_event.record()
    for _ in range(decisions):
        if graph is not None:
            graph.replay()
        else:
            batch._step_into_buffers()
    end_event.record()
    torch.cuda.synchronize()
    wall_s = max(1e-9, time.perf_counter() - start_wall)
    device_s = float(start_event.elapsed_time(end_event)) / 1000.0
    physical_steps = int(decisions * arenas * G.ACTION_REPEAT)
    if not all(tensor_finite(torch, x) for x in (
        batch._g_obs, batch._g_logp, batch._g_values, batch._g_reward)):
        raise FloatingPointError("non-finite values found in CUDA decision loop")
    peak_alloc = float(torch.cuda.max_memory_allocated()) / (1024 ** 2)
    peak_reserved = float(torch.cuda.max_memory_reserved()) / (1024 ** 2)
    row = {
        "arenas": arenas, "mode": "cuda_graph" if graph is not None else "eager",
        "repeat": repeat, "decisions": decisions, "physical_steps": physical_steps,
        "wall_s": wall_s, "device_s": device_s,
        "host_s": max(0.0, wall_s - device_s),
        "steps_per_s": physical_steps / wall_s,
        "decisions_per_s": decisions / wall_s,
        "peak_alloc_mib": peak_alloc, "peak_reserved_mib": peak_reserved,
        "capture_wall_s": capture_wall, "graph_used": graph is not None,
        "weights_loaded": weights_loaded, "large_residual_active": bool(policy._large_residual_active()),
        "width": width, "depth": depth,
    }
    del graph, batch, policy
    gc.collect()
    torch.cuda.empty_cache()
    return row


def full_rollout_smoke(torch, batch_cls, arenas: int = 32, decisions: int = 12,
                       width: int = 256, depth: int = 2) -> str:
    policy = G.ActorCritic(seed=99, width=width, depth=depth, device_mode="cpu")
    batch = batch_cls(engine=G, policy=policy, count=arenas, blue_n=1, red_n=1,
                      opponent_mode="heuristic", max_decisions=decisions,
                      device="cuda", seed=99, use_cuda_graph=True)
    torch.cuda.synchronize()
    results = batch.collect()
    torch.cuda.synchronize()
    if not results:
        raise RuntimeError("full rollout returned no episodes")
    records = 0
    for i, row in enumerate(results):
        packed = row[0]
        records += len(packed)
        for field in ("obs", "logp", "value", "reward", "adv", "returns"):
            value = np.asarray(getattr(packed, field))
            if not np.isfinite(value).all():
                raise FloatingPointError(f"full rollout episode {i}: non-finite {field}")
        if not np.isfinite(float(row[1])):
            raise FloatingPointError(f"full rollout episode {i}: non-finite total reward")
    return (f"full_rollout_smoke=PASS arenas={arenas} decisions={decisions} "
            f"episodes={len(results)} records={records} cuda_graph={batch.last_cuda_graph_used}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Measure GravitrueX fast GPU physics: eager vs CUDA Graph.")
    ap.add_argument("--arenas", default=os.environ.get("GX_BENCH_ARENAS", "64,128,256,384,512,768,1024"),
                    help="comma-separated arena batch sizes")
    ap.add_argument("--decisions", type=int, default=int(os.environ.get("GX_BENCH_DECISIONS", "24")),
                    help="decision steps in the steady-state loop")
    ap.add_argument("--repeats", type=int, default=int(os.environ.get("GX_BENCH_REPEATS", "2")))
    ap.add_argument("--width", type=int, default=int(os.environ.get("GX_BENCH_WIDTH", "1536")))
    ap.add_argument("--depth", type=int, default=int(os.environ.get("GX_BENCH_DEPTH", "4")))
    ap.add_argument("--weights", default=os.environ.get("GX_BENCH_WEIGHTS", ""),
                    help="optional exact weights_*.npz checkpoint; default is newest checkpoint matching width/depth")
    ap.add_argument("--record-budget", type=int, default=0,
                    help="optional record budget per rollout; 0 means no cap for this microbenchmark")
    ap.add_argument("--skip-smoke", action="store_true", help="skip full-rollout finite-value smoke test")
    args = ap.parse_args()

    try:
        import torch
    except Exception as exc:
        print(f"ERROR: PyTorch unavailable: {exc}")
        return 2
    if not torch.cuda.is_available():
        print("ERROR: CUDA is not available. Start the program with the NVIDIA/CUDA environment.")
        return 2

    arenas = []
    for raw in args.arenas.split(","):
        raw = raw.strip()
        if raw:
            value = int(raw)
            if value < 1 or value > 1024:
                raise ValueError(f"arena size must be in 1..1024, got {value}")
            if value not in arenas:
                arenas.append(value)
    if not arenas:
        raise ValueError("empty --arenas list")
    if args.decisions < 4 or args.repeats < 1:
        raise ValueError("--decisions must be >= 4 and --repeats >= 1")

    batch_cls = G._load_gpu_batch_class()
    selected_weights = select_weights(args.width, args.depth, args.weights.strip() or None)
    device = torch.cuda.get_device_properties(0)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = G.SAVE_DIR / "benchmarks"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"gpu_fast_stage6_{stamp}.txt"
    latest_path = out_dir / "gpu_fast_stage6_latest.txt"
    lines = [
        "GRAVITRUEX STAGE 6 — GPU FAST PATH BENCHMARK",
        f"time={dt.datetime.now().isoformat(timespec='seconds')}",
        f"gpu={torch.cuda.get_device_name(0)}", f"torch={torch.__version__}",
        f"cuda_runtime={torch.version.cuda}",
        f"sm_count={device.multi_processor_count}",
        f"vram_mib={device.total_memory / (1024**2):.0f}",
        f"policy_width={args.width} depth={args.depth}",
        f"weights_path={selected_weights if selected_weights else 'none (fresh test weights)'}",
        f"arenas={arenas} decisions={args.decisions} repeats={args.repeats} record_budget={args.record_budget or 'uncapped'}",
        "metrics=steady-state _step_into_buffers loop; graph capture/warmup is measured separately",
        "",
        "arenas mode repeat wall_s device_s host_s steps_per_s capture_s peak_alloc_MiB peak_reserved_MiB weights large_branch graph status",
    ]
    rows = []
    for n in arenas:
        for mode in (False, True):
            for rep in range(1, args.repeats + 1):
                label = "cuda_graph" if mode else "eager"
                try:
                    row = measure_variant(torch, batch_cls, n, args.decisions, args.width,
                                          args.depth, mode, rep, args.record_budget, selected_weights)
                    rows.append(row)
                    line = (f"{n:4d} {label:10s} {rep:2d} {row['wall_s']:7.3f} "
                            f"{row['device_s']:7.3f} {row['host_s']:7.3f} {row['steps_per_s']:10.0f} "
                            f"{row['capture_wall_s']:7.3f} {row['peak_alloc_mib']:9.0f} "
                            f"{row['peak_reserved_mib']:10.0f} {str(row['weights_loaded']):7s} "
                            f"{str(row['large_residual_active']):12s} {str(row['graph_used']):5s} OK")
                except Exception as exc:
                    try:
                        torch.cuda.empty_cache()
                    except Exception:
                        pass
                    line = f"{n:4d} {label:10s} {rep:2d} FAIL {type(exc).__name__}: {exc}"
                    print(line)
                lines.append(line)
                print(line)

    lines += ["", "SUMMARY (average measured steps/s)"]
    for n in arenas:
        parts = []
        for mode in ("eager", "cuda_graph"):
            vals = [r["steps_per_s"] for r in rows if r["arenas"] == n and r["mode"] == mode]
            if vals:
                parts.append(f"{mode}={sum(vals)/len(vals):,.0f}")
        if parts:
            lines.append(f"arenas={n}: " + ", ".join(parts))
    if not args.skip_smoke:
        try:
            smoke = full_rollout_smoke(torch, batch_cls)
        except Exception as exc:
            smoke = f"full_rollout_smoke=FAIL {type(exc).__name__}: {exc}"
        lines += ["", smoke]
        print(smoke)
    lines += ["", "Interpretation: prefer total steps/s and valid full rollouts, not a single nvidia-smi sample.",
              "The benchmark does not update or save policy weights."]
    text = "\n".join(lines) + "\n"
    out_path.write_text(text, encoding="utf-8")
    latest_path.write_text(text, encoding="utf-8")
    print(f"\nReport saved: {out_path}")
    print(f"Latest report: {latest_path}")
    return 0 if rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
