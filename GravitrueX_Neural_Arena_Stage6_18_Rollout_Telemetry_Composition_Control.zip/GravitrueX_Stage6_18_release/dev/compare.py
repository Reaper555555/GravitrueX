# -*- coding: utf-8 -*-
"""Compare the original and the optimized GPU arena batch."""
import importlib.util, sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
import torch_stub
sys.modules["torch"] = torch_stub
import engine_stub


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def run(path, count=4, decisions=24, seed=7, mode="heuristic", constant_policy=True, **kw):
    mod = load(path, "m_" + os.path.basename(path).replace(".", "_"))
    policy = engine_stub.FakePolicy(width=32, depth=2, seed=5)
    torch_stub.reset_stats()
    batch = mod.GPUVectorArenaBatch(
        engine=engine_stub, policy=policy, count=count, blue_n=1, red_n=1,
        random_compositions=False, opponent_mode=mode,
        max_decisions=decisions, device="cpu", seed=seed, **kw)
    if constant_policy:
        batch._policy_sample = _const_policy.__get__(batch, type(batch))
    res = batch.collect()
    return res, dict(torch_stub.STATS)


def _const_policy(self, obs):
    t = torch_stub
    n = self.policy_indices.shape[0]
    actions = t.Tensor(np.tile(np.array([[1, 2, 1, 1]], dtype=np.int64), (n, 1)))
    logp = t.Tensor(np.zeros(n, dtype=np.float32))
    values = t.Tensor(np.zeros(n, dtype=np.float32))
    full_actions = t.Tensor(np.ones((self.E * self.S, 4), dtype=np.int64))
    full_actions[:, 0] = 1
    full_actions[:, 1] = 2
    full_actions[:, 2] = 1
    full_actions[:, 3] = 1
    full_logp = t.Tensor(np.zeros(self.E * self.S, dtype=np.float32))
    full_values = t.Tensor(np.zeros(self.E * self.S, dtype=np.float32))
    full_actions.index_copy_(0, self.policy_indices, actions)
    full_logp.index_copy_(0, self.policy_indices, logp)
    full_values.index_copy_(0, self.policy_indices, values)
    return (full_actions.reshape(self.E, self.S, 4),
            full_logp.reshape(self.E, self.S), full_values.reshape(self.E, self.S))


def digest(results):
    out = []
    for packed, ep, oc, bn, rn, steps, metrics in results:
        out.append({
            "obs": packed.obs.copy(), "action": packed.action.copy(),
            "logp": packed.logp.copy(), "value": packed.value.copy(),
            "reward": packed.reward.copy(), "done": packed.done.copy(),
            "adv": packed.adv.copy(), "returns": packed.returns.copy(),
            "ep": ep, "steps": steps, "metrics": metrics,
        })
    return out


def _finite_array(label, value, bad):
    arr = np.asarray(value)
    if arr.dtype.kind in "fc" and not np.isfinite(arr).all():
        n_nan = int(np.isnan(arr).sum())
        n_inf = int(np.isinf(arr).sum())
        bad.append(f"{label}: non-finite values (NaN={n_nan}, Inf={n_inf})")
        return False
    return True


def compare(a, b, tol=2e-4, label=""):
    """Strict equivalence: non-finite values are failures, never ignored by nanmax."""
    worst = 0.0
    bad = []
    assert len(a) == len(b), (len(a), len(b))
    float_fields = ("obs", "logp", "value", "reward", "adv", "returns")
    for i, (x, y) in enumerate(zip(a, b)):
        for k in ("obs", "action", "logp", "value", "reward", "done", "adv", "returns"):
            u, v = np.asarray(x[k]), np.asarray(y[k])
            if u.shape != v.shape:
                bad.append(f"arena{i}.{k}: shape {u.shape} vs {v.shape}")
                continue
            if k in float_fields:
                good_u = _finite_array(f"arena{i}.{k}.original", u, bad)
                good_v = _finite_array(f"arena{i}.{k}.optimized", v, bad)
                if not (good_u and good_v):
                    continue
                d = float(np.max(np.abs(u - v))) if u.size else 0.0
                worst = max(worst, d)
                if d > tol:
                    bad.append(f"arena{i}.{k}: max abs diff {d:.3e}")
            else:
                if not np.array_equal(u, v):
                    bad.append(f"arena{i}.{k}: {int((u != v).sum())} differing entries")
        if not np.isfinite(float(x["ep"])) or not np.isfinite(float(y["ep"])):
            bad.append(f"arena{i}.ep_reward: non-finite (original={x['ep']}, optimized={y['ep']})")
        elif abs(float(x["ep"]) - float(y["ep"])) > 1e-3:
            bad.append(f"arena{i}.ep_reward: {x['ep']} vs {y['ep']}")
        # Battle metrics are part of the contract too. Compare numeric fields and
        # reject NaN/Inf explicitly rather than silently accepting them.
        mx, my = x.get("metrics", {}), y.get("metrics", {})
        # New rollout-only telemetry is intentionally absent from the Stage 4 reference.
        # It does not affect physics/results; compare the shared contract fields and reject
        # non-finite/different values there as before.
        telemetry_only = {"policy_fire_rate", "teacher_fire_rate"}
        core_mx = {k: v for k, v in mx.items() if k not in telemetry_only}
        core_my = {k: v for k, v in my.items() if k not in telemetry_only}
        if set(core_mx) != set(core_my):
            bad.append(f"arena{i}.metrics keys differ: {sorted(core_mx)} vs {sorted(core_my)}")
        for key in set(core_mx).intersection(core_my):
            vx, vy = core_mx[key], core_my[key]
            if isinstance(vx, (int, float, np.number)) and isinstance(vy, (int, float, np.number)):
                if not np.isfinite(float(vx)) or not np.isfinite(float(vy)):
                    bad.append(f"arena{i}.metrics.{key}: non-finite")
                elif abs(float(vx) - float(vy)) > 1e-3:
                    bad.append(f"arena{i}.metrics.{key}: {vx} vs {vy}")
            elif vx != vy:
                bad.append(f"arena{i}.metrics.{key}: {vx!r} vs {vy!r}")
    print(f"[{label}] worst float diff = {worst:.3e}  problems={len(bad)}")
    for line in bad[:20]:
        print("   !", line)
    if len(bad) > 20:
        print(f"   ... and {len(bad) - 20} more")
    return not bad


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("original")
    ap.add_argument("optimized")
    ap.add_argument("--count", type=int, default=4)
    ap.add_argument("--decisions", type=int, default=24)
    ap.add_argument("--mode", default="heuristic")
    args = ap.parse_args()
    # Stage 4 can emit an intermediate inf-inf warning for a dead target; the
    # strict comparison below verifies that no non-finite values escape into data.
    with np.errstate(invalid="ignore", divide="ignore", over="ignore"):
        ra, sa = run(args.original, args.count, args.decisions, mode=args.mode)
        rb, sb = run(args.optimized, args.count, args.decisions, mode=args.mode)
    print(f"original : ops/dec={sa['ops']/args.decisions:8.1f}  syncs/dec={sa['syncs']/args.decisions:6.3f}  elems={sa['elements']:,}")
    print(f"optimized: ops/dec={sb['ops']/args.decisions:8.1f}  syncs/dec={sb['syncs']/args.decisions:6.3f}  elems={sb['elements']:,}")
    if sb["ops"] < sa["ops"]:
        print(f"ops change: {sa['ops'] / max(1, sb['ops']):.2f}x fewer operations")
    else:
        print(f"ops change: +{(sb['ops'] / max(1, sa['ops']) - 1) * 100:.1f}% operations")
    if sb["syncs"] < sa["syncs"]:
        print(f"sync change: {sa['syncs'] / max(1, sb['syncs']):.1f}x fewer synchronizations")
    else:
        print(f"sync change: +{(sb['syncs'] / max(1, sa['syncs']) - 1) * 100:.1f}% synchronizations")
    if sb["elements"] < sa["elements"]:
        print(f"element change: {(1 - sb['elements'] / max(1, sa['elements'])) * 100:.1f}% fewer processed elements")
    else:
        print(f"element change: +{(sb['elements'] / max(1, sa['elements']) - 1) * 100:.1f}% processed elements")
    ok = compare(digest(ra), digest(rb), label="equivalence")
    print("EQUIVALENT" if ok else "DIFFERENT")
    if not ok:
        raise SystemExit(1)
