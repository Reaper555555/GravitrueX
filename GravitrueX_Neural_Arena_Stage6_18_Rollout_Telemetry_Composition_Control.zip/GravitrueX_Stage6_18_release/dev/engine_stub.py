# -*- coding: utf-8 -*-
"""Engine + policy stand-ins for the arena harness (no Tkinter, no PyTorch)."""
from __future__ import annotations

from typing import Any, Dict, List

import numpy as np

WORLD_SCALE = 5.0
WORLD_W = 1000.0 * WORLD_SCALE
WORLD_H = 700.0 * WORLD_SCALE
OBS_POS_X = 500.0
OBS_POS_Y = 350.0
CAMERA_BASE_WIDTH = 2400.0
FPS = 60
DISPLAY_FPS_TARGET = 60
DISPLAY_FRAME_MS = 1000.0 / DISPLAY_FPS_TARGET
TRAINING_UI_FPS_TARGET = 10
DT = 1.0 / FPS
ACTION_REPEAT = 4
POLICY_HZ = FPS / ACTION_REPEAT
MAX_SPEED = 205.0
ACCEL_FORWARD = 235.0
ACCEL_STRAFE = 195.0
TURN_RATE = 2.95
DRAG = 0.16
SHIP_RADIUS = 10.0
MAX_HP = 100.0
MAX_SHIELD = 38.0
SHIELD_REGEN = 5.0
SHIELD_DELAY = 1.6
BULLET_SPEED = 455.0
BULLET_DAMAGE = 10.0
BULLET_RADIUS = 2.8
BULLET_TTL = 2.15
FIRE_COOLDOWN = 0.48
# Keep combat reward constants aligned with gravitruex_ai.py for tensor parity tests.
REWARD_DAMAGE_DEALT = 0.10
REWARD_DAMAGE_TAKEN = 0.035
REWARD_PER_KILL = 13.0
REWARD_DEATH = 7.0
REWARD_SHOT_AIM_BONUS = 0.08
REWARD_SHOT_BASE_COST = 0.004
REWARD_STEP_COST = 0.001
OBS_BASE_SIZE = 64
OBS_EXTRA_SIZE = 32
OBS_SIZE = OBS_BASE_SIZE + OBS_EXTRA_SIZE
HIDDEN = 128


class PackedExperience:
    """Same contract as gravitruex_ai.PackedExperience."""

    __slots__ = ("obs", "action", "logp", "value", "reward", "done", "adv", "returns",
                 "teacher_action", "teacher_mask")

    def __init__(self, obs, action, logp, value, reward, done, adv, returns,
                 teacher_action=None, teacher_mask=None):
        self.obs = np.asarray(obs, dtype=np.float32)
        self.action = np.asarray(action, dtype=np.int64)
        self.logp = np.asarray(logp, dtype=np.float32).reshape(-1)
        self.value = np.asarray(value, dtype=np.float32).reshape(-1)
        self.reward = np.asarray(reward, dtype=np.float32).reshape(-1)
        self.done = np.asarray(done, dtype=np.bool_).reshape(-1)
        self.adv = np.asarray(adv, dtype=np.float32).reshape(-1)
        self.returns = np.asarray(returns, dtype=np.float32).reshape(-1)
        self.teacher_action = self.action.copy() if teacher_action is None else np.asarray(teacher_action, dtype=np.int64)
        self.teacher_mask = np.zeros(len(self.logp), dtype=np.bool_) if teacher_mask is None else np.asarray(teacher_mask, dtype=np.bool_).reshape(-1)
        n = len(self.logp)
        if self.obs.shape[0] != n or self.action.shape[0] != n:
            raise ValueError("PackedExperience: размерности массивов не совпадают")
        if self.teacher_action.shape != self.action.shape or len(self.teacher_mask) != n:
            raise ValueError("PackedExperience: invalid teacher label shapes")

    def __len__(self):
        return int(self.logp.shape[0])

    def __bool__(self):
        return len(self) > 0


class FakePolicy:
    """Minimal ActorCritic stand-in: NumPy weights, no torch state."""

    def __init__(self, width: int = 32, depth: int = 2, seed: int = 5):
        rng = np.random.default_rng(seed)
        self.width = width
        self.depth = depth
        self.params: Dict[str, np.ndarray] = {
            "W1": rng.normal(0, 0.1, (OBS_SIZE, width)).astype(np.float32),
            "b1": np.zeros(width, np.float32),
            "W2": rng.normal(0, 0.1, (width, width)).astype(np.float32),
            "b2": np.zeros(width, np.float32),
            "Wt": rng.normal(0, 0.1, (width, 3)).astype(np.float32),
            "bt": np.zeros(3, np.float32),
            "Wf": rng.normal(0, 0.1, (width, 3)).astype(np.float32),
            "bf": np.zeros(3, np.float32),
            "Ws": rng.normal(0, 0.1, (width, 3)).astype(np.float32),
            "bs": np.zeros(3, np.float32),
            "Wfire": rng.normal(0, 0.1, (width, 1)).astype(np.float32),
            "bfire": np.zeros(1, np.float32),
            "Wv": rng.normal(0, 0.1, (width, 1)).astype(np.float32),
            "bv": np.zeros(1, np.float32),
        }
        self._torch_params = None
        self._torch_device = ""
        self.last_device = ""
        self.last_inference_backend = ""

    def _large_residual_active(self) -> bool:
        return False
