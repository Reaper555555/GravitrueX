# -*- coding: utf-8 -*-
"""Run the vector-physics part of the project self-test on the NumPy stub.

Reproduces step [6/6] of `gravitruex_ai.py --self-test`: the tensor arena runs
against the scalar Arena, plus the categorical action regression check. The
PPO part is skipped because the stub has no autograd.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, APP)

import numpy as np
import torch_stub

sys.modules["torch"] = torch_stub

import gravitruex_ai as G

GPUVectorArenaBatch = G._load_gpu_batch_class()
print(f"backend module: {'FAST (stage 5)' if G.GPU_FAST_PATH else 'stage 4 original'}")

policy = G.ActorCritic(seed=71, width=32, depth=2, device_mode="cpu")
batch = GPUVectorArenaBatch(engine=G, policy=policy, count=2, blue_n=1, red_n=1,
                             opponent_mode="heuristic", max_decisions=8,
                             device="cpu", seed=71)
results = batch.collect()
assert len(results) == 2, f"Expected 2 parallel arenas, got {len(results)}"
assert all(row[0] and row[5] > 0 for row in results)
assert all(np.isfinite(float(row[1])) for row in results)
for row in results:
    packed = row[0]
    for field in ("obs", "logp", "value", "reward", "adv", "returns"):
        values = np.asarray(getattr(packed, field))
        assert np.isfinite(values).all(), f"non-finite rollout values in {field}"
    for key, value in row[6].items():
        if isinstance(value, (int, float, np.number)):
            assert np.isfinite(float(value)), f"non-finite episode metric {key}"
print(f"  OK: {len(results)} arenas in one tensor batch; "
      f"records={sum(len(row[0]) for row in results):,}; rollout values finite")

# Regression: scalar engine constants must be normalized before CUDA graph capture.
# Some customized/local variants wrap constants as CPU scalar tensors.
_orig_ttl = G.BULLET_TTL
try:
    G.BULLET_TTL = torch_stub.Tensor(np.asarray(2.15, dtype=np.float32))
    ttl_probe = GPUVectorArenaBatch(engine=G, policy=policy, count=2, blue_n=1, red_n=1,
                                    opponent_mode="heuristic", max_decisions=8,
                                    device="cpu", seed=718)
    assert abs(ttl_probe._bullet_ttl_value - 2.15) < 1e-6
    assert np.asarray(ttl_probe._bullet_ttl_spawn_values).shape == (2, 10)
    ttl_probe._physics_tick(torch_stub.Tensor(np.tile(np.array([[1, 1, 1, 0]], dtype=np.int64), (2, 10, 1))),
                            torch_stub.Tensor(np.ones(2, dtype=bool)))
finally:
    G.BULLET_TTL = _orig_ttl
print("  OK: CPU scalar-tensor BULLET_TTL normalized before capture; projectile TTL source stays device-local")

# Snapshot/restore regression. In particular, `alive` must be snapshotted: a
# CUDA graph warmup can kill a zero-HP ship, and the arena must be restored.
batch_module = sys.modules[GPUVectorArenaBatch.__module__]
assert "alive" in batch_module._STATE_ATTRS, "mutable alive state omitted from graph snapshot"
snapshot = batch._snapshot_state()
for state_name in batch_module._STATE_ATTRS:
    state = getattr(batch, state_name)
    state[...] = np.zeros_like(np.asarray(state))
batch._restore_state(snapshot)
for state_name, expected in snapshot.items():
    assert np.array_equal(np.asarray(getattr(batch, state_name)), np.asarray(expected)), \
        f"snapshot/restore lost mutable state: {state_name}"
print(f"  OK: snapshot/restore covers all {len(snapshot)} mutable fields, including alive")

# Regression test: categorical action 2 must produce forward acceleration.
batch.vx.zero_(); batch.vy.zero_(); batch.heading.zero_()
batch.active_env[:] = True
batch.alive[:] = batch.present
batch.hp[:] = batch.present.float() * G.MAX_HP
probe_actions = torch_stub.Tensor(np.ones((batch.E, batch.S, 4), dtype=np.int64))
probe_actions[:, 0, 1] = 2
batch._physics_tick(probe_actions, torch_stub.Tensor(np.ones(batch.E, dtype=bool)))
assert bool((batch.vx[:, 0] > 0).all()), "Categorical forward thrust (2) did not accelerate forward"
assert bool((batch.vx[:, 1].abs() < 1e-5).all()), "Neutral thrust (1) changed forward velocity"
print("  OK: categorical action mapping regression")

# One-tick physics parity check against the scalar Arena.
ref_env = G.Arena(seed=714)
ref_env.reset(2, 2, seed=714)
parity = GPUVectorArenaBatch(engine=G, policy=policy, count=1, blue_n=2, red_n=2,
                              opponent_mode="heuristic", max_decisions=8,
                              device="cpu", seed=714)
ship_to_slot = {}
red_index = 0
for ship in ref_env.ships:
    if ship.team == 0:
        slot = sum(1 for other in ref_env.ships if other.team == 0 and other.sid < ship.sid)
    else:
        slot = 5 + red_index
        red_index += 1
    ship_to_slot[ship.sid] = slot
    for tensor_name, attr_name in (("x", "x"), ("y", "y"), ("vx", "vx"), ("vy", "vy"),
                                   ("heading", "heading"), ("hp", "hp"), ("shield", "shield"),
                                   ("cooldown", "cooldown"), ("last_hit_time", "last_hit_time")):
        getattr(parity, tensor_name)[0, slot] = float(getattr(ship, attr_name))
parity.sim_time[0] = ref_env.sim_time
parity.active_env[:] = True
parity.alive[:] = parity.present
parity.balive.zero_()
ref_actions = {}
cat_actions = torch_stub.Tensor(np.ones((1, parity.S, 4), dtype=np.int64))
for i, ship in enumerate(ref_env.ships):
    action = G.Action(turn=(i % 3) - 1, thrust=((i + 1) % 3) - 1,
                      strafe=((i + 2) % 3) - 1, fire=0)
    ref_actions[ship.sid] = action
    slot = ship_to_slot[ship.sid]
    cat_actions[0, slot, 0] = action.turn + 1
    cat_actions[0, slot, 1] = action.thrust + 1
    cat_actions[0, slot, 2] = action.strafe + 1
ref_env.physics_tick(ref_actions)
parity._physics_tick(cat_actions, torch_stub.Tensor(np.ones(1, dtype=bool)))
errors = []
for ship in ref_env.ships:
    slot = ship_to_slot[ship.sid]
    for tensor_name, attr_name in (("x", "x"), ("y", "y"), ("vx", "vx"), ("vy", "vy"),
                                   ("heading", "heading"), ("hp", "hp")):
        errors.append(abs(float(getattr(parity, tensor_name)[0, slot].item())
                          - float(getattr(ship, attr_name))))
max_error = max(errors) if errors else 0.0
assert max_error < 1e-3, f"GPU tensor physics diverged from scalar arena by {max_error}"
print(f"  OK: vector physics one-tick parity with scalar Arena; max absolute state error={max_error:.2e}")

# Extra: the projectile spawn path must place bullets identically to the
# stage 4 implementation, otherwise the observation of incoming shots changes.
orig = G._load_gpu_batch_class()
import importlib.util
spec = importlib.util.spec_from_file_location(
    "stage4", os.path.join(APP, "gravitruex_gpu_batch_stage4_original.py"))
stage4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stage4)
a4 = stage4.GPUVectorArenaBatch(engine=G, policy=policy, count=2, blue_n=1, red_n=1,
                                opponent_mode="heuristic", max_decisions=8,
                                device="cpu", seed=99)
a5 = GPUVectorArenaBatch(engine=G, policy=policy, count=2, blue_n=1, red_n=1,
                          opponent_mode="heuristic", max_decisions=8,
                          device="cpu", seed=99)
acts = torch_stub.Tensor(np.tile(np.array([[1, 2, 1, 1]], dtype=np.int64), (2, 10, 1)))
tick = torch_stub.Tensor(np.ones(2, dtype=bool))
for _ in range(12):
    a4._physics_tick(acts, tick.clone())
    a5._physics_tick(acts, tick.clone())
for name in ("x", "y", "vx", "vy", "heading", "hp", "shield", "cooldown", "kills", "shots"):
    assert np.allclose(np.asarray(getattr(a4, name)), np.asarray(getattr(a5, name)), atol=1e-6), name
bx4 = np.asarray(a4.bx)[:, :a4.B]
bx5 = np.asarray(a5.bx)[:, :a5.B]
assert np.allclose(bx4, bx5, atol=1e-6), "projectile positions diverged"
assert np.array_equal(np.asarray(a4.balive)[:, :a4.B], np.asarray(a5.balive)[:, :a5.B]), "alive flags diverged"
assert np.array_equal(np.asarray(a4.bowner)[:, :a4.B], np.asarray(a5.bowner)[:, :a5.B]), "bullet owners diverged"
print("  OK: 12 physics ticks match the stage 4 implementation bit for bit (incl. projectiles)")

print("VECTOR PHYSICS TESTS PASSED")
