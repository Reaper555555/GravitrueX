# -*- coding: utf-8 -*-
"""Minimal NumPy-backed stand-in for the PyTorch API used by gravitruex_gpu_batch.

Purpose: the sandbox has no PyTorch wheel available, so this shim lets us execute
the real arena code on NumPy, compare the original and the optimized implementation
numerically, and count how many tensor operations (== CUDA kernel launches) each
decision costs. It is a test harness, not a PyTorch replacement.
"""
from __future__ import annotations

import contextlib
import math
from typing import Any, Dict, List, Optional

import numpy as np

# ---------------------------------------------------------------- op accounting
STATS: Dict[str, Any] = {
    "ops": 0,            # every tensor-producing call (proxy for kernel launches)
    "syncs": 0,          # calls that force a device->host transfer in real CUDA
    "elements": 0,       # total output elements produced (proxy for real work)
    "by_name": {},
}


def reset_stats() -> None:
    STATS["ops"] = 0
    STATS["syncs"] = 0
    STATS["elements"] = 0
    STATS["by_name"] = {}


def _count(name: str, out: Any = None, sync: bool = False) -> Any:
    STATS["ops"] += 1
    if sync:
        STATS["syncs"] += 1
    key = STATS["by_name"]
    key[name] = key.get(name, 0) + 1
    if isinstance(out, np.ndarray):
        STATS["elements"] += int(out.size)
    return out


class Tensor(np.ndarray):
    """np.ndarray subclass carrying the torch methods the arena code calls."""

    def __new__(cls, data, dtype=None):
        obj = np.asarray(data, dtype=dtype).view(cls)
        return obj

    # -- shape plumbing ---------------------------------------------------
    def view(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        elif len(shape) == 1 and isinstance(shape[0], int):
            shape = (shape[0],)
        return _count("view", self.reshape(shape))

    def reshape(self, *shape, **kw):
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        return _count("reshape", np.ndarray.reshape(self, *shape, **kw))

    def squeeze(self, axis=None):
        return _count("squeeze", np.ndarray.squeeze(self, axis=axis))

    def unsqueeze(self, axis):
        return _count("unsqueeze", np.expand_dims(self, axis))

    def expand(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        src = np.asarray(self)
        shape = list(shape)
        if len(shape) != src.ndim:
            raise ValueError(f"expand: {shape} vs {src.shape}")
        for i, dim in enumerate(shape):
            if dim == -1:
                shape[i] = src.shape[i]
        return _count("expand", Tensor(np.broadcast_to(src, tuple(shape))))

    def permute(self, *dims):
        if len(dims) == 1 and isinstance(dims[0], (tuple, list)):
            dims = tuple(dims[0])
        return _count("permute", Tensor(np.asarray(self).transpose(dims)))

    def transpose(self, *dims):
        if len(dims) == 1 and isinstance(dims[0], (tuple, list)):
            dims = tuple(dims[0])
        return _count("transpose", Tensor(np.asarray(self).transpose(dims)))

    def contiguous(self):
        return _count("contiguous", np.ascontiguousarray(self))

    def clone(self):
        return _count("clone", np.ndarray.copy(self))

    def detach(self):
        return self

    def to(self, *args, **kwargs):
        dtype = kwargs.get("dtype")
        if dtype is None and args:
            dtype = args[0] if not isinstance(args[0], (torch_device,)) else None
        if dtype is None:
            return self
        return _count("to", self.astype(_np_dtype(dtype)))

    def cpu(self):
        return self

    def numpy(self):
        return np.asarray(self)

    def item(self):
        _count("item", None, sync=True)
        return np.ndarray.item(self)

    def numel(self):
        return int(self.size)

    def __setitem__(self, key, value):
        # torch index_put_ is a real kernel; count it like the other ops.
        if isinstance(key, tuple) and any(isinstance(k, (np.ndarray, list)) for k in key):
            _count("index_put", None)
        return np.ndarray.__setitem__(self, key, value)

    # -- dtype ------------------------------------------------------------
    def float(self):
        return _count("float", self.astype(np.float32))

    def long(self):
        return _count("long", self.astype(np.int64))

    def bool(self):
        return _count("bool", self.astype(bool))

    def int(self):
        return _count("int", self.astype(np.int64))

    # -- reductions -------------------------------------------------------
    def _dim(self, dim, kwargs):
        if dim is None:
            dim = kwargs.pop("axis", None)
        kwargs.pop("out", None)
        kwargs.pop("keepdims", None)
        return dim, kwargs

    def sum(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        return _count("sum", Tensor(np.sum(np.asarray(self), axis=dim, keepdims=keepdim)))

    def mean(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        return _count("mean", Tensor(np.mean(np.asarray(self), axis=dim, keepdims=keepdim)))

    def amin(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        return _count("amin", Tensor(np.min(np.asarray(self), axis=dim, keepdims=keepdim)))

    def amax(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        return _count("amax", Tensor(np.max(np.asarray(self), axis=dim, keepdims=keepdim)))

    def max(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        if dim is None:
            return _count("max", Tensor(np.max(np.asarray(self))))
        values = np.max(np.asarray(self), axis=dim, keepdims=keepdim)
        idx = np.argmax(np.asarray(self), axis=dim)
        return _count("max", (Tensor(values), Tensor(idx)))

    def min(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        if dim is None:
            return _count("min", Tensor(np.min(np.asarray(self))))
        values = np.min(np.asarray(self), axis=dim, keepdims=keepdim)
        idx = np.argmin(np.asarray(self), axis=dim)
        return _count("min", (Tensor(values), Tensor(idx)))

    def argmin(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        return _count("argmin", Tensor(np.argmin(np.asarray(self), axis=dim)))

    def argmax(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        return _count("argmax", Tensor(np.argmax(np.asarray(self), axis=dim)))

    def any(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        out = np.any(np.asarray(self), axis=dim, keepdims=keepdim)
        return _count("any", Tensor(out) if isinstance(out, np.ndarray) else out)

    def all(self, dim=None, keepdim=False, **kw):
        dim, kw = self._dim(dim, kw)
        out = np.all(np.asarray(self), axis=dim, keepdims=keepdim)
        return _count("all", Tensor(out) if isinstance(out, np.ndarray) else out)

    def cumsum(self, dim=None):
        return _count("cumsum", np.cumsum(self, axis=dim))

    # -- elementwise ------------------------------------------------------
    def clamp(self, min=None, max=None):
        return _count("clamp", np.clip(self, a_min=min, a_max=max))

    def clamp_min(self, v):
        return _count("clamp_min", np.maximum(self, v))

    def clamp_max(self, v):
        return _count("clamp_max", np.minimum(self, v))

    def abs(self):
        return _count("abs", np.abs(self))

    def sqrt(self):
        return _count("sqrt", np.sqrt(self))

    def sin(self):
        return _count("sin", np.sin(self))

    def cos(self):
        return _count("cos", np.cos(self))

    def exp(self):
        return _count("exp", np.exp(self))

    def log(self):
        return _count("log", np.log(self))

    def sigmoid(self):
        return _count("sigmoid", 1.0 / (1.0 + np.exp(-self)))

    def remainder(self, other):
        return _count("remainder", np.mod(self, other))

    def isfinite(self):
        return _count("isfinite", np.isfinite(self))

    def masked_fill(self, mask, value):
        return _count("masked_fill", Tensor(np.where(np.asarray(mask), value, np.asarray(self))))

    def logical_or(self):
        return _count("logical_or", Tensor(np.logical_or(np.asarray(self))))

    # -- indexing / scatter ------------------------------------------------
    def gather(self, dim, index):
        return _count("gather", Tensor(_torch_gather(self, index, dim)))

    def index_select(self, dim, index):
        arr = np.asarray(self)
        idx = np.asarray(index)
        if dim == 0:
            out = arr[idx]
        else:
            length = idx.shape[0]
            shape = (arr.shape[0], length) + arr.shape[2:]
            idx1 = idx.reshape((1, length) + (1,) * (arr.ndim - 2))
            out = np.take_along_axis(arr, np.broadcast_to(idx1, shape), axis=dim)
        return _count("index_select", Tensor(out))

    def scatter_add_(self, dim, index, src):
        out = np.array(self, copy=True)
        idx = np.asarray(index)
        src_a = np.asarray(src)
        grids = np.indices(idx.shape)
        grids[dim] = idx
        np.add.at(out, tuple(grids), src_a)
        self[...] = out
        return _count("scatter_add_", None)

    def scatter_(self, dim, index, src):
        arr = np.array(self, copy=True)
        idx = np.asarray(index)
        src_a = np.asarray(src)
        grids = np.indices(idx.shape)
        grids[dim] = idx
        arr[tuple(grids)] = src_a
        self[...] = arr
        return _count("scatter_", None)

    def index_copy_(self, dim, index, src):
        if dim == 0:
            self[index] = src
        else:
            self[:, index] = src
        return _count("index_copy_", None)

    def index_copy(self, dim, index, src):
        out = np.array(self, copy=True)
        out.index_copy_(dim, index, src)
        return out

    def zero_(self):
        self[...] = 0
        return _count("zero_", None)

    def fill_(self, v):
        self[...] = v
        return _count("fill_", None)

    def copy_(self, src):
        self[...] = src
        return _count("copy_", None)


def _np_dtype(dtype):
    if dtype in (float32, "float32", "torch.float32"):
        return np.float32
    if dtype in (float64, "float64", "torch.float64"):
        return np.float64
    if dtype in (int64, "int64", "torch.int64", "long"):
        return np.int64
    if dtype in (bool, "bool", "torch.bool"):
        return np.bool_
    return dtype


float32 = np.float32
float64 = np.float64
int64 = np.int64
bool_ = np.bool_
long = np.int64
bool = np.bool_          # torch.dtype alias used as dtype=t.bool
float = np.float64


class torch_device:
    def __init__(self, spec):
        self.spec = str(spec)
        self.type = "cuda" if "cuda" in self.spec else "cpu"

    def __str__(self):
        return self.spec

    def __repr__(self):
        return f"device({self.spec!r})"


def device(spec):
    return torch_device(spec)


class Generator:
    """Deterministic replacement for torch.Generator."""

    def __init__(self, device=None):
        self._rng = np.random.default_rng(0)

    def manual_seed(self, seed):
        self._rng = np.random.default_rng(int(seed))
        return self

    def random(self, shape):
        return self._rng.random(shape).astype(np.float32)


# ------------------------------------------------------------------ module API
def as_tensor(data, dtype=None, device=None):
    return _count("as_tensor", Tensor(data, dtype=_np_dtype(dtype) if dtype is not None else None))


def ones(shape, dtype=None, device=None):
    return _count("ones", Tensor(np.ones(shape, dtype=_np_dtype(dtype) if dtype is not None else np.float32)))


def zeros(shape, dtype=None, device=None):
    return _count("zeros", Tensor(np.zeros(shape, dtype=_np_dtype(dtype) if dtype is not None else np.float32)))


def zeros_like(x, dtype=None):
    return _count("zeros_like", Tensor(np.zeros_like(np.asarray(x), dtype=_np_dtype(dtype) if dtype else None)))


def ones_like(x, dtype=None):
    return _count("ones_like", Tensor(np.ones_like(np.asarray(x), dtype=_np_dtype(dtype) if dtype else None)))


def full(shape, value, dtype=None, device=None):
    return _count("full", Tensor(np.full(shape, value, dtype=_np_dtype(dtype) if dtype is not None else np.float32)))


def full_like(x, value, dtype=None):
    return _count("full_like", Tensor(np.full_like(np.asarray(x), value,
                                                   dtype=_np_dtype(dtype) if dtype else np.asarray(x).dtype)))


def eye(n, dtype=None, device=None):
    return _count("eye", Tensor(np.eye(n, dtype=_np_dtype(dtype) if dtype is not None else np.float32)))


def arange(n, device=None):
    return _count("arange", Tensor(np.arange(n, dtype=np.int64)))


def cat(seq, dim=0):
    return _count("cat", Tensor(np.concatenate([np.asarray(s) for s in seq], axis=dim)))


def stack(seq, dim=0):
    return _count("stack", Tensor(np.stack([np.asarray(s) for s in seq], axis=dim)))


def where(cond, a=None, b=None):
    if a is None and b is None:
        # torch.where(condition) == nonzero(condition): data dependent shape, and in
        # real CUDA this forces a device->host synchronization.
        parts = [Tensor(idx.astype(np.int64)) for idx in np.nonzero(np.asarray(cond))]
        return _count("where_nonzero", tuple(parts), sync=True)
    return _count("where", Tensor(np.where(np.asarray(cond), np.asarray(a), np.asarray(b))))


def _torch_gather(arr, index, dim):
    """torch.gather semantics: index may be smaller on the non-gather dims."""
    arr = np.asarray(arr)
    index = np.asarray(index)
    ndim = arr.ndim
    if index.ndim != ndim:
        raise ValueError("gather: rank mismatch")
    grids = np.indices(index.shape)
    grids[dim] = index
    return arr[tuple(grids)]


def gather(x, dim, index):
    return _count("gather", Tensor(_torch_gather(x, index, dim)))


class _TopK(tuple):
    """torch.topk returns a named tuple with .values / .indices."""

    def __new__(cls, values, indices):
        return super().__new__(cls, (values, indices))

    @property
    def values(self):
        return self[0]

    @property
    def indices(self):
        return self[1]


def topk(x, k, dim=-1, largest=True, sorted=True):
    arr = np.asarray(x)
    order = np.argsort(-arr if largest else arr, axis=dim, kind="stable")
    idx = order[..., :k]
    vals = np.take_along_axis(arr, idx, axis=dim)
    if not sorted:
        raise NotImplementedError
    return _count("topk", _TopK(Tensor(vals), Tensor(idx.astype(np.int64))))


def sort(x, dim=-1, descending=False, stable=False):
    arr = np.asarray(x)
    order = np.argsort(-arr if descending else arr, axis=dim, kind="stable")
    vals = np.take_along_axis(arr, order, axis=dim)
    return _count("sort", (Tensor(vals), Tensor(order.astype(np.int64))))


def log_softmax(x, dim=-1):
    arr = np.asarray(x, dtype=np.float64)
    m = arr.max(axis=dim, keepdims=True)
    lse = m + np.log(np.exp(arr - m).sum(axis=dim, keepdims=True))
    return _count("log_softmax", Tensor((arr - lse).astype(np.float32)))


_DEFAULT_GEN = Generator()


def multinomial(probs, num_samples=1, replacement=False, generator=None):
    if generator is None:
        generator = _DEFAULT_GEN
    probs = np.asarray(probs, dtype=np.float64)
    flat = probs.reshape(-1, probs.shape[-1])
    draws = np.array([generator._rng.choice(p.shape[0], size=num_samples, p=p / p.sum())
                      for p in flat])
    return _count("multinomial", Tensor(draws.reshape(probs.shape[:-1] + (num_samples,)).astype(np.int64)))


def rand(shape, generator=None, device=None, dtype=None):
    if generator is None:
        generator = Generator()
    return _count("rand", Tensor(generator.random(shape)))


def clamp(x, min=None, max=None):
    return _count("clamp", Tensor(np.clip(np.asarray(x), a_min=min, a_max=max)))


def sqrt(x):
    return _count("sqrt", Tensor(np.sqrt(np.asarray(x))))


def sin(x):
    return _count("sin", Tensor(np.sin(np.asarray(x))))


def cos(x):
    return _count("cos", Tensor(np.cos(np.asarray(x))))


def atan2(a, b):
    return _count("atan2", Tensor(np.arctan2(np.asarray(a), np.asarray(b))))


def remainder(a, b):
    return _count("remainder", Tensor(np.mod(np.asarray(a), np.asarray(b))))


def exp(x):
    return _count("exp", Tensor(np.exp(np.asarray(x))))


def log(x):
    return _count("log", Tensor(np.log(np.asarray(x))))


def sigmoid(x):
    return _count("sigmoid", Tensor(1.0 / (1.0 + np.exp(-np.asarray(x)))))


def isfinite(x):
    return _count("isfinite", Tensor(np.isfinite(np.asarray(x))))


def sum(x, dim=None, keepdim=False):
    return _count("sum", np.sum(np.asarray(x), axis=dim, keepdims=keepdim))


def manual_seed(seed):
    return None


@contextlib.contextmanager
def no_grad():
    yield


@contextlib.contextmanager
def inference_mode():
    yield


class _Categorical:
    def __init__(self, logits=None, probs=None):
        self.logits = np.asarray(logits, dtype=np.float64)
        self._lsm = log_softmax(self.logits, dim=-1)

    def log_prob(self, a):
        idx = np.asarray(a, dtype=np.int64)[..., None]
        return _count("dist_log_prob", Tensor(np.take_along_axis(self._lsm, idx, axis=-1).squeeze(-1).astype(np.float32)))

    def entropy(self):
        p = np.exp(self._lsm)
        return _count("dist_entropy", Tensor((-p * self._lsm).sum(axis=-1).astype(np.float32)))


class _Bernoulli:
    def __init__(self, logits=None, probs=None):
        self.logits = np.asarray(logits, dtype=np.float64)

    def entropy(self):
        p = 1.0 / (1.0 + np.exp(-self.logits))
        h = -(p * np.log(p + 1e-12) + (1 - p) * np.log(1 - p + 1e-12))
        return _count("bern_entropy", Tensor(h.astype(np.float32)))


class _Distributions:
    Categorical = _Categorical
    Bernoulli = _Bernoulli


class _Functional:
    @staticmethod
    def binary_cross_entropy_with_logits(logits, targets, reduction="none"):
        z = np.asarray(logits, dtype=np.float64)
        y = np.asarray(targets, dtype=np.float64)
        loss = np.maximum(z, 0) - z * y + np.log1p(np.exp(-np.abs(z)))
        if reduction == "none":
            return _count("bce", Tensor(loss.astype(np.float32)))
        return _count("bce", Tensor(np.asarray(loss.mean(), dtype=np.float32)))


class _NN:
    functional = _Functional


class _Cuda:
    @staticmethod
    def is_available():
        return False

    @staticmethod
    def synchronize(device=None):
        return None


distributions = _Distributions
nn = _NN
cuda = _Cuda


def __getattr__(name):
    # Any other torch attribute used by the arena code degrades to a NumPy call.
    if name.startswith("_"):
        raise AttributeError(name)
    np_name = {"float": "float64", "long": "int64", "int": "int64", "bool": "bool"}.get(name, name)
    if hasattr(np, np_name):
        def _f(*args, **kwargs):
            kwargs.pop("device", None)
            out = getattr(np, np_name)(*args, **kwargs)
            if isinstance(out, np.ndarray):
                return Tensor(out)
            return out
        return _f
    raise AttributeError(f"torch_stub has no attribute {name!r}")
