# -*- coding: utf-8 -*-
"""Tensor-batched GravitrueX arenas for CUDA rollouts.

The class intentionally receives the running game module as `engine`, avoiding
an import of the UI script under a second module name when launched as __main__.
It batches independent arena physics and policy inference on one device. CPU
ProcessPool workers can run ordinary Arena rollouts concurrently in parallel.
"""
from __future__ import annotations

import math
import random
import time
from typing import Any, Dict, List, Optional

import numpy as np


class GPUVectorArenaBatch:
    """Multiple independent toroidal arenas evaluated together with torch tensors.

    The training observations preserve the current 96-feature layout. Physics is
    fixed-timestep and uses the same major constants as the scalar Arena, but is
    implemented as batched tensor operations. This is an experimental accelerator
    path; parity tests should be used when physics rules are changed.
    """

    def __init__(self, engine: Any, policy: Any, count: int = 8,
                 blue_n: int = 1, red_n: int = 1, random_compositions: bool = False,
                 opponent_mode: str = "heuristic", max_decisions: int = 240,
                 device: str = "cuda", seed: Optional[int] = None):
        import torch
        self.torch = torch
        self.e = engine
        self.policy = policy
        self.device = torch.device(device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("GPU-пакет арен требует доступную CUDA-видеокарту и CUDA-сборку PyTorch.")
        self.count = max(1, min(128, int(count)))
        self.max_decisions = max(8, int(max_decisions))
        self.opponent_mode = str(opponent_mode)
        if self.opponent_mode not in ("heuristic", "selfplay"):
            raise RuntimeError("GPU-пакетная физика поддерживает только эвристического противника и self-play на первом этапе.")
        self.rng = random.Random(seed if seed is not None else time.time_ns())
        if random_compositions:
            self.blue_counts = np.asarray([self.rng.randint(1, 5) for _ in range(self.count)], dtype=np.int64)
            self.red_counts = np.asarray([self.rng.randint(1, 5) for _ in range(self.count)], dtype=np.int64)
        else:
            self.blue_counts = np.full(self.count, max(1, min(5, int(blue_n))), dtype=np.int64)
            self.red_counts = np.full(self.count, max(1, min(5, int(red_n))), dtype=np.int64)
        self.E, self.S, self.B = self.count, 10, 256
        self.t = torch
        self.dev = self.device
        self._torch_generator = None
        try:
            self._torch_generator = torch.Generator(device=self.device)
            self._torch_generator.manual_seed(self.rng.randrange(1, 2**31 - 1))
        except Exception:
            self._torch_generator = None
        # Keep rollout inference tensors separate when PPO is configured for the
        # other device. Calling policy._ensure_torch("cuda") here would reset the
        # CPU AdamW state every hybrid cycle when the user deliberately trains PPO
        # on CPU. Use the learner's parameters only when they already live on this
        # exact device; otherwise make an inference-only snapshot from NumPy weights.
        learner_params = getattr(self.policy, "_torch_params", None)
        learner_device = str(getattr(self.policy, "_torch_device", ""))
        if learner_params is not None and learner_device == str(self.device):
            self.p = learner_params
            self._owns_policy_snapshot = False
        else:
            self.p = {k: torch.as_tensor(np.asarray(v).copy(), dtype=torch.float32, device=self.device)
                      for k, v in self.policy.params.items()}
            self._owns_policy_snapshot = True
        self.width = int(getattr(self.policy, "width", 0))
        self.depth = int(getattr(self.policy, "depth", 0))
        self.large_residual_active = bool(self.policy._large_residual_active()) if hasattr(self.policy, "_large_residual_active") else False
        self._initialize_state()

    def _rand(self, shape, lo=0.0, hi=1.0):
        if self._torch_generator is None:
            r = self.t.rand(shape, device=self.dev)
        else:
            r = self.t.rand(shape, generator=self._torch_generator, device=self.dev)
        return lo + (hi - lo) * r

    def _initialize_state(self):
        t, E, S, B, dev, e = self.t, self.E, self.S, self.B, self.dev, self.e
        self.ship_slot = t.arange(S, device=dev).view(1, S).expand(E, S)
        self.team = (t.arange(S, device=dev) >= 5).long().view(1, S).expand(E, S)
        bn = t.as_tensor(self.blue_counts, dtype=t.long, device=dev).view(E, 1)
        rn = t.as_tensor(self.red_counts, dtype=t.long, device=dev).view(E, 1)
        slots = t.arange(5, device=dev).view(1, 5)
        self.present = t.cat((slots < bn, slots < rn), dim=1)
        model_slots = self.present if self.opponent_mode == "selfplay" else (self.present & (self.team == 0))
        self.policy_indices = t.where(model_slots.reshape(-1))[0]
        self.alive = self.present.clone()
        self.x = t.zeros((E, S), dtype=t.float32, device=dev)
        self.y = t.zeros_like(self.x)
        self.vx = (self._rand((E, S), -10.0, 10.0) * self.present.float())
        self.vy = (self._rand((E, S), -10.0, 10.0) * self.present.float())
        # Spawn roughly in the center engagement zone; ship IDs have fixed team slots.
        center_x, center_y = e.WORLD_W * .5, e.WORLD_H * .5
        off = min(500.0, e.WORLD_W * .16)
        for s in range(S):
            if s < 5:
                rank = float(s)
                count = bn[:, 0].float()
                valid = self.present[:, s]
                base_x = center_x - off
                base_y = center_y + (rank - (count - 1.0) * .5) * 78.0
                self.x[:, s] = (base_x + self._rand((E,), -55, 55)) * valid.float()
                self.y[:, s] = (base_y + self._rand((E,), -32, 32)) * valid.float()
            else:
                rank = float(s - 5)
                count = rn[:, 0].float()
                valid = self.present[:, s]
                base_x = center_x + off
                base_y = center_y + (rank - (count - 1.0) * .5) * 78.0
                self.x[:, s] = (base_x + self._rand((E,), -55, 55)) * valid.float()
                self.y[:, s] = (base_y + self._rand((E,), -32, 32)) * valid.float()
        self.heading = t.zeros((E, S), dtype=t.float32, device=dev)
        self.heading[:, :5] = self._rand((E, 5), -.18, .18)
        self.heading[:, 5:] = math.pi + self._rand((E, 5), -.18, .18)
        self.hp = self.present.float() * e.MAX_HP
        self.shield = self.present.float() * e.MAX_SHIELD
        self.cooldown = self._rand((E, S), .05, .35) * self.present.float()
        self.last_hit_time = t.full((E, S), -100.0, dtype=t.float32, device=dev)
        self.last_turn = t.zeros((E, S), dtype=t.float32, device=dev)
        self.damage_dealt = t.zeros((E, S), dtype=t.float32, device=dev)
        self.damage_taken = t.zeros_like(self.damage_dealt)
        self.kills = t.zeros((E, S), dtype=t.float32, device=dev)
        self.shots = t.zeros((E, S), dtype=t.float32, device=dev)
        self.deaths = t.zeros((E, S), dtype=t.float32, device=dev)
        self.bx = t.zeros((E, B), dtype=t.float32, device=dev)
        self.by = t.zeros_like(self.bx)
        self.bvx = t.zeros_like(self.bx)
        self.bvy = t.zeros_like(self.bx)
        self.bteam = t.zeros((E, B), dtype=t.long, device=dev)
        self.bowner = t.full((E, B), -1, dtype=t.long, device=dev)
        self.bttl = t.zeros_like(self.bx)
        self.balive = t.zeros((E, B), dtype=t.bool, device=dev)
        self.sim_time = t.zeros(E, dtype=t.float32, device=dev)
        self.step_count = t.zeros(E, dtype=t.long, device=dev)
        self.active_env = t.ones(E, dtype=t.bool, device=dev)
        self.slot_team = (t.arange(S, device=dev) >= 5).long().view(1, S).expand(E, S)
        self._identity = t.eye(S, dtype=t.bool, device=dev).view(1, S, S)

    def _wrap(self, delta, size):
        return self.t.where(delta > size * .5, delta - size,
                            self.t.where(delta < -size * .5, delta + size, delta))

    def _angle(self, a):
        return self.t.atan2(self.t.sin(a), self.t.cos(a))

    def _pairwise(self):
        # [E, observing ship i, observed ship j]
        dx = self._wrap(self.x[:, None, :] - self.x[:, :, None], self.e.WORLD_W)
        dy = self._wrap(self.y[:, None, :] - self.y[:, :, None], self.e.WORLD_H)
        rvx = self.vx[:, None, :] - self.vx[:, :, None]
        rvy = self.vy[:, None, :] - self.vy[:, :, None]
        dist = self.t.sqrt(dx * dx + dy * dy + 1e-8)
        pair_alive = self.alive[:, :, None] & self.alive[:, None, :]
        enemy = pair_alive & (self.team[:, :, None] != self.team[:, None, :])
        ally = pair_alive & (self.team[:, :, None] == self.team[:, None, :]) & ~self._identity
        return dx, dy, rvx, rvy, dist, enemy, ally

    def _pair_gather(self, mat, idx):
        return self.t.gather(mat, 2, idx)

    def _topk(self, dist, valid, k):
        masked = self.t.where(valid, dist, self.t.full_like(dist, float("inf")))
        vals, inds = self.t.topk(masked, k=k, dim=-1, largest=False, sorted=True)
        good = self.t.isfinite(vals)
        return inds, good, vals

    def _bullet_rel(self):
        # [E,S,B], vector from ship to bullet and velocity relative to ship.
        dx = self._wrap(self.bx[:, None, :] - self.x[:, :, None], self.e.WORLD_W)
        dy = self._wrap(self.by[:, None, :] - self.y[:, :, None], self.e.WORLD_H)
        rvx = self.bvx[:, None, :] - self.vx[:, :, None]
        rvy = self.bvy[:, None, :] - self.vy[:, :, None]
        dist = self.t.sqrt(dx * dx + dy * dy + 1e-8)
        valid = (self.balive[:, None, :] & self.alive[:, :, None] &
                 (self.bteam[:, None, :] != self.team[:, :, None]))
        return dx, dy, rvx, rvy, dist, valid

    def _observe(self):
        t, e = self.t, self.e
        dx, dy, rvx, rvy, dist, enemy_valid, ally_valid = self._pairwise()
        inf = t.full_like(dist, float("inf"))
        score = dist * (.82 + .18 * self.hp[:, None, :] / e.MAX_HP)
        score = t.where(enemy_valid, score, inf)
        target_idx = score.argmin(dim=-1)
        has_target = enemy_valid.any(dim=-1)
        tx = self._pair_gather(dx, target_idx[..., None]).squeeze(-1)
        ty = self._pair_gather(dy, target_idx[..., None]).squeeze(-1)
        tvx = self._pair_gather(rvx, target_idx[..., None]).squeeze(-1)
        tvy = self._pair_gather(rvy, target_idx[..., None]).squeeze(-1)
        tdist = t.sqrt(tx * tx + ty * ty + 1e-8)
        thp = self.hp.gather(1, target_idx) / e.MAX_HP
        tshield = self.shield.gather(1, target_idx) / e.MAX_SHIELD
        terr = self._angle(t.atan2(ty, tx) - self.heading)
        closing_dot = (tvx * tx + tvy * ty) / (tdist * e.MAX_SPEED * 2)
        closing_dot = t.clamp(closing_dot, -1, 1)
        c, s = t.cos(self.heading), t.sin(self.heading)
        local_vx = (self.vx * c + self.vy * s) / e.MAX_SPEED
        local_vy = (-self.vx * s + self.vy * c) / e.MAX_SPEED
        speed = t.sqrt(self.vx * self.vx + self.vy * self.vy)
        feat = [
            t.clamp(local_vx, -1, 1), t.clamp(local_vy, -1, 1),
            t.clamp(speed / e.MAX_SPEED, 0, 1), self.hp / e.MAX_HP,
            self.shield / e.MAX_SHIELD, t.clamp(self.cooldown / e.FIRE_COOLDOWN, 0, 1),
            self.last_turn, t.ones_like(self.x),
            t.where(has_target, t.clamp(tx / e.OBS_POS_X, -1, 1), 0),
            t.where(has_target, t.clamp(ty / e.OBS_POS_Y, -1, 1), 0),
            t.where(has_target, t.clamp(tvx / (e.MAX_SPEED * 2), -1, 1), 0),
            t.where(has_target, t.clamp(tvy / (e.MAX_SPEED * 2), -1, 1), 0),
            t.where(has_target, t.sin(terr), 0), t.where(has_target, t.cos(terr), 0),
            t.where(has_target, t.clamp(tdist / 650.0, 0, 1), 0),
            t.where(has_target, thp, 0), t.where(has_target, tshield, 0),
            t.where(has_target, closing_dot, 0),
        ]
        # Three nearest enemies: append each entity as a contiguous feature row.
        ei, egood, _ = self._topk(dist, enemy_valid, 3)
        for j in range(3):
            idx = ei[..., j]
            good = egood[..., j]
            for source, denom in ((dx, e.OBS_POS_X), (dy, e.OBS_POS_Y),
                                  (rvx, e.MAX_SPEED * 2), (rvy, e.MAX_SPEED * 2)):
                v = self._pair_gather(source, idx.unsqueeze(-1)).squeeze(-1)
                feat.append(t.where(good, t.clamp(v / denom, -1, 1), 0))
            hp_j = self.hp.gather(1, idx) / e.MAX_HP
            sh_j = self.shield.gather(1, idx) / e.MAX_SHIELD
            feat.extend([t.where(good, hp_j, 0), t.where(good, sh_j, 0)])
        # Three nearest allies: dx,dy,hp,speed; each ally occupies four features.
        ai, agood, _ = self._topk(dist, ally_valid, 3)
        for j in range(3):
            idx = ai[..., j]
            good = agood[..., j]
            for source, denom in ((dx, e.OBS_POS_X), (dy, e.OBS_POS_Y)):
                v = self._pair_gather(source, idx.unsqueeze(-1)).squeeze(-1)
                feat.append(t.where(good, t.clamp(v / denom, -1, 1), 0))
            ahp = self.hp.gather(1, idx) / e.MAX_HP
            aspeed = t.gather(speed, 1, idx) / e.MAX_SPEED
            feat.extend([t.where(good, ahp, 0), t.where(good, t.clamp(aspeed, 0, 1), 0)])
        # Incoming projectiles, first two nearest; preserve per-projectile ordering.
        bdx, bdy, bvx, bvy, bdist, bvalid = self._bullet_rel()
        bi, bgood, bvals = self._topk(bdist, bvalid, 2)
        for j in range(2):
            idx = bi[..., j]
            good = bgood[..., j]
            for source, denom in ((bdx, e.OBS_POS_X), (bdy, e.OBS_POS_Y),
                                  (bvx, e.BULLET_SPEED * 1.5), (bvy, e.BULLET_SPEED * 1.5)):
                v = t.gather(source, 2, idx.unsqueeze(-1)).squeeze(-1)
                feat.append(t.where(good, t.clamp(v / denom, -1, 1), 0))
        # Team/urgency summary.
        blue_alive = ((self.team == 0) & self.alive).sum(dim=1).float()
        red_alive = ((self.team == 1) & self.alive).sum(dim=1).float()
        alive_f = self.alive.float()
        mean_hp = (self.hp * alive_f).sum(dim=1) / alive_f.sum(dim=1).clamp_min(1.0) / e.MAX_HP
        mean_hp_i = mean_hp[:, None].expand(-1, self.S)
        own_count = t.where(self.team == 0, blue_alive[:, None], red_alive[:, None])
        opp_count = t.where(self.team == 0, red_alive[:, None], blue_alive[:, None])
        own_hp_sum = ((self.hp / e.MAX_HP) * self.alive.float() * (self.team == self.team[:, :1])).sum(dim=1) if False else None
        own_mean = t.zeros_like(self.hp)
        opp_mean = t.zeros_like(self.hp)
        for tm in (0, 1):
            m = self.alive & (self.team == tm)
            avg = ((self.hp / e.MAX_HP) * m.float()).sum(dim=1) / m.float().sum(dim=1).clamp_min(1.0)
            if tm == 0:
                own_mean[:, :5] = avg[:, None]
                opp_mean[:, :5] = ((self.hp / e.MAX_HP) * (self.alive & (self.team == 1)).float()).sum(dim=1)[:, None] / ((self.alive & (self.team == 1)).float().sum(dim=1).clamp_min(1.0)[:, None])
            else:
                own_mean[:, 5:] = avg[:, None]
                opp_mean[:, 5:] = ((self.hp / e.MAX_HP) * (self.alive & (self.team == 0)).float()).sum(dim=1)[:, None] / ((self.alive & (self.team == 0)).float().sum(dim=1).clamp_min(1.0)[:, None])
        if self.B:
            closest_dist, closest_idx = bdist.masked_fill(~bvalid, float("inf")).min(dim=-1)
            closest_has = t.isfinite(closest_dist)
            c_bdx = t.gather(bdx, 2, closest_idx.unsqueeze(-1)).squeeze(-1)
            c_bdy = t.gather(bdy, 2, closest_idx.unsqueeze(-1)).squeeze(-1)
            c_bvx = t.gather(bvx, 2, closest_idx.unsqueeze(-1)).squeeze(-1)
            c_bvy = t.gather(bvy, 2, closest_idx.unsqueeze(-1)).squeeze(-1)
            c_dist = closest_dist.clamp_min(1.0)
            min_closing = -((c_bvx * c_bdx + c_bvy * c_bdy) / c_dist) / e.MAX_SPEED
            bullet_t = t.clamp(closest_dist / 240.0, 0, 1)
            bullet_t = t.where(closest_has, bullet_t, 1.0)
            min_closing = t.where(closest_has, t.clamp(min_closing, -1, 1), 0.0)
        else:
            bullet_t = t.ones_like(self.x); min_closing = t.zeros_like(self.x)
        feat.extend([
            own_count / 5.0, opp_count / 5.0, own_mean, opp_mean,
            bullet_t, min_closing,
            t.where(has_target, t.clamp(terr / math.pi, -1, 1), 0),
            t.where(has_target, t.clamp(tdist / 650.0, 0, 1), 1),
        ])
        # Tactical target context.
        trvx, trvy = tvx, tvy
        tdist_safe = tdist.clamp_min(1.0)
        closing = -(trvx * tx + trvy * ty) / tdist_safe
        ttc = t.where(closing > 0, tdist / closing.clamp_min(1.0), 5.0)
        lead_t = t.clamp(tdist / e.BULLET_SPEED, 0, .72)
        lead_err = self._angle(t.atan2(ty + trvy * lead_t, tx + trvx * lead_t) - self.heading)
        vel_angle = self._angle(t.atan2(trvy, trvx) - self.heading)
        vel_nonzero = (trvx.abs() + trvy.abs()) > 1e-5
        feat.extend([
            t.where(has_target, t.clamp(tdist / 1800.0, 0, 1), 0),
            t.where(has_target, t.clamp(closing / (e.MAX_SPEED * 1.5), -1, 1), 0),
            t.where(has_target, t.clamp(ttc / 5.0, 0, 1), 0),
            t.where(has_target, t.sin(lead_err), 0), t.where(has_target, t.cos(lead_err), 0),
            t.where(has_target, t.clamp(t.sqrt(trvx * trvx + trvy * trvy) / (e.MAX_SPEED * 2), 0, 1), 0),
            t.where(has_target & vel_nonzero, t.sin(vel_angle), 0),
            t.where(has_target & vel_nonzero, t.cos(vel_angle), 0),
        ])
        # Two more allies, nearest first; nearest 3 used above so exclude their indices.
        ally_rank = t.where(ally_valid, dist, inf)
        aextra_idx, aextra_good, _ = self._topk(ally_rank, ally_valid, 5)
        for j in (0, 1):
            idx = aextra_idx[..., j]
            good = aextra_good[..., j]
            for source, denom in ((dx, 1500.0), (dy, 1500.0), (rvx, e.MAX_SPEED * 2), (rvy, e.MAX_SPEED * 2)):
                v = self._pair_gather(source, idx.unsqueeze(-1)).squeeze(-1)
                feat.append(t.where(good, t.clamp(v / denom, -1, 1), 0))
            vhp = t.gather((self.hp / e.MAX_HP)[:, None, :].expand(-1, self.S, -1), 2, idx.unsqueeze(-1)).squeeze(-1)
            feat.append(t.where(good, vhp, 0))
        # Two additional closest enemies: closest-approach time, miss distance, closing, angle.
        eextra_idx, eextra_good, _ = self._topk(dist, enemy_valid, 5)
        for j in (0, 1):
            idx = eextra_idx[..., j]
            good = eextra_good[..., j]
            edx = self._pair_gather(dx, idx.unsqueeze(-1)).squeeze(-1)
            edy = self._pair_gather(dy, idx.unsqueeze(-1)).squeeze(-1)
            evx = self._pair_gather(rvx, idx.unsqueeze(-1)).squeeze(-1)
            evy = self._pair_gather(rvy, idx.unsqueeze(-1)).squeeze(-1)
            vv = evx * evx + evy * evy
            tca = t.clamp(-(edx * evx + edy * evy) / vv.clamp_min(1e-5), 0, 2.5)
            miss = t.sqrt((edx + evx * tca) ** 2 + (edy + evy * tca) ** 2)
            d = t.sqrt(edx * edx + edy * edy).clamp_min(1.0)
            c_e = -(edx * evx + edy * evy) / d
            angle_e = self._angle(t.atan2(edy, edx) - self.heading)
            feat.extend([
                t.where(good, t.clamp(tca / 2.5, 0, 1), 0),
                t.where(good, t.clamp(miss / 500.0, 0, 1), 0),
                t.where(good, t.clamp(c_e / (e.MAX_SPEED * 1.5), -1, 1), 0),
                t.where(good, t.sin(angle_e), 0),
            ])
        # Bullet closest approach context. Additional two nearest incoming projectiles.
        bdist_masked = t.where(bvalid, bdist, t.full_like(bdist, float("inf")))
        bex_idx, bex_good, _ = self._topk(bdist_masked, bvalid, 4)
        for j in (0, 1):
            idx = bex_idx[..., j]
            good = bex_good[..., j]
            edx = t.gather(bdx, 2, idx.unsqueeze(-1)).squeeze(-1)
            edy = t.gather(bdy, 2, idx.unsqueeze(-1)).squeeze(-1)
            evx = t.gather(bvx, 2, idx.unsqueeze(-1)).squeeze(-1)
            evy = t.gather(bvy, 2, idx.unsqueeze(-1)).squeeze(-1)
            vv = evx * evx + evy * evy
            tca = t.clamp(-(edx * evx + edy * evy) / vv.clamp_min(1e-5), 0, 2.5)
            miss = t.sqrt((edx + evx * tca) ** 2 + (edy + evy * tca) ** 2)
            feat.extend([t.where(good, t.clamp(tca / 2.5, 0, 1), 1.0),
                         t.where(good, t.clamp(miss / 60.0, 0, 1), 1.0)])
        # Nearby ally/enemy counts within 600 units.
        nearby_a = ((ally_valid & (dist < 600.0)).sum(dim=-1).float() / 4.0).clamp(0, 1)
        nearby_e = ((enemy_valid & (dist < 600.0)).sum(dim=-1).float() / 5.0).clamp(0, 1)
        feat.extend([nearby_a, nearby_e])
        obs = t.stack(feat, dim=-1).to(dtype=t.float32)
        if obs.shape[-1] != e.OBS_SIZE:
            raise RuntimeError(f"GPU observations have {obs.shape[-1]} features, expected {e.OBS_SIZE}")
        # Mask observations for empty/dead slots; those slots aren't trained.
        return obs

    def _aim(self):
        t, e = self.t, self.e
        dx, dy, rvx, rvy, dist, enemy_valid, _ = self._pairwise()
        score = dist * (.82 + .18 * self.hp[:, None, :] / e.MAX_HP)
        idx = t.where(enemy_valid, score, t.full_like(score, float("inf"))).argmin(dim=-1)
        has = enemy_valid.any(dim=-1)
        tx = self._pair_gather(dx, idx[..., None]).squeeze(-1)
        ty = self._pair_gather(dy, idx[..., None]).squeeze(-1)
        tvx = self._pair_gather(rvx, idx[..., None]).squeeze(-1)
        tvy = self._pair_gather(rvy, idx[..., None]).squeeze(-1)
        d = t.sqrt(tx * tx + ty * ty).clamp_min(1.0)
        lead = t.clamp(d / e.BULLET_SPEED, 0, .72)
        angle = t.atan2(ty + tvy * lead, tx + tvx * lead)
        aim = t.cos(self._angle(angle - self.heading))
        aim = t.where(has, aim, -1.0)
        d = t.where(has, d, t.full_like(d, float("inf")))
        return aim, d

    def _policy_forward(self, x):
        """Inference from this rollout's device-local weight snapshot."""
        t, p = self.t, self.p
        h = t.tanh(x @ p["W1"] + p["b1"])
        h = t.tanh(h @ p["W2"] + p["b2"])
        logits = {
            "turn": h @ p["Wt"] + p["bt"],
            "thrust": h @ p["Wf"] + p["bf"],
            "strafe": h @ p["Ws"] + p["bs"],
            "fire": (h @ p["Wfire"] + p["bfire"]).squeeze(-1),
        }
        value = (h @ p["Wv"] + p["bv"]).squeeze(-1)
        if self.large_residual_active:
            g = x
            for i in range(self.depth):
                g = t.tanh(g @ p[f"G_W{i}"] + p[f"G_b{i}"])
            logits["turn"] = logits["turn"] + g @ p["G_Wt"] + p["G_bt"]
            logits["thrust"] = logits["thrust"] + g @ p["G_Wf"] + p["G_bf"]
            logits["strafe"] = logits["strafe"] + g @ p["G_Ws"] + p["G_bs"]
            logits["fire"] = logits["fire"] + (g @ p["G_Wfire"] + p["G_bfire"]).squeeze(-1)
            value = value + (g @ p["G_Wv"] + p["G_bv"]).squeeze(-1)
        return logits, value

    def _policy_sample(self, obs):
        t = self.t
        flat_obs = obs.reshape(-1, self.e.OBS_SIZE)
        # The set of controlled slots is fixed for a rollout batch, so we avoid
        # running the large policy on empty slots or heuristic-controlled enemies.
        x = flat_obs.index_select(0, self.policy_indices)
        with t.no_grad():
            logits, values = self._policy_forward(x)
            cats, logp = [], t.zeros(x.shape[0], dtype=t.float32, device=self.dev)
            for key in ("turn", "thrust", "strafe"):
                lp = t.log_softmax(logits[key], dim=-1)
                a = t.multinomial(lp.exp(), 1).squeeze(-1)
                cats.append(a)
                logp += lp.gather(1, a[:, None]).squeeze(-1)
            fire_logits = logits["fire"].reshape(-1)
            fire_p = t.sigmoid(fire_logits)
            fire = (self._rand((x.shape[0],)) < fire_p).long()
            cats.append(fire)
            logp += -t.nn.functional.binary_cross_entropy_with_logits(fire_logits, fire.float(), reduction="none")
            selected_actions = t.stack(cats, dim=-1)
            selected_values = values.reshape(-1)
        # Full-size outputs simplify physics integration; unselected slots receive coast.
        full_actions = t.zeros((self.E * self.S, 4), dtype=t.long, device=self.dev)
        full_actions[:, :3] = 1
        full_logp = t.zeros(self.E * self.S, dtype=t.float32, device=self.dev)
        full_values = t.zeros_like(full_logp)
        full_actions.index_copy_(0, self.policy_indices, selected_actions)
        full_logp.index_copy_(0, self.policy_indices, logp)
        full_values.index_copy_(0, self.policy_indices, selected_values)
        return (full_actions.reshape(self.E, self.S, 4),
                full_logp.reshape(self.E, self.S), full_values.reshape(self.E, self.S))

    def _heuristic_actions(self):
        t, e = self.t, self.e
        dx, dy, rvx, rvy, dist, enemy_valid, _ = self._pairwise()
        score = dist * (.82 + .18 * self.hp[:, None, :] / e.MAX_HP)
        idx = t.where(enemy_valid, score, t.full_like(score, float("inf"))).argmin(dim=-1)
        has = enemy_valid.any(dim=-1)
        tx = self._pair_gather(dx, idx[..., None]).squeeze(-1)
        ty = self._pair_gather(dy, idx[..., None]).squeeze(-1)
        tvx = self._pair_gather(rvx, idx[..., None]).squeeze(-1)
        tvy = self._pair_gather(rvy, idx[..., None]).squeeze(-1)
        d = t.sqrt(tx * tx + ty * ty).clamp_min(1.0)
        lead = t.clamp(d / e.BULLET_SPEED, 0, .72)
        desired = t.atan2(ty + tvy * lead, tx + tvx * lead)
        err = self._angle(desired - self.heading)
        turn = t.where(err.abs() < .045, 0, t.where(err > 0, 1, -1))
        thrust = t.where(d > 285, 1, t.where(d < 185, -1, 0))
        slots = t.arange(self.S, device=self.dev).view(1, self.S).expand(self.E, self.S)
        strafe = t.where(slots % 2 == 0, 1, -1)
        bdx, bdy, bvx, bvy, bdist, bvalid = self._bullet_rel()
        vv = bvx * bvx + bvy * bvy
        tc = -(bdx * bvx + bdy * bvy) / vv.clamp_min(1e-5)
        tc = tc.clamp(0, .72)
        miss_x = bdx + bvx * tc
        miss_y = bdy + bvy * tc
        miss = t.sqrt(miss_x * miss_x + miss_y * miss_y)
        danger = bvalid & (vv > 1e-5) & (-(bdx * bvx + bdy * bvy) / vv.clamp_min(1e-5) > 0) & (miss < 27)
        score_d = t.where(danger, (27 - miss) / tc.clamp_min(.08), t.zeros_like(miss))
        best_score, bi = score_d.max(dim=-1)
        cx = t.gather(miss_x, 2, bi.unsqueeze(-1)).squeeze(-1)
        cy = t.gather(miss_y, 2, bi.unsqueeze(-1)).squeeze(-1)
        nx, ny = -t.sin(self.heading), t.cos(self.heading)
        dot = nx * (-cx) + ny * (-cy)
        dodge = best_score > 0
        strafe = t.where(dodge, t.where(dot >= 0, 1, -1), strafe)
        thrust = t.where(dodge & (d < 230), 1, thrust)
        fire = (err.abs() < .105) & (d < 720) & (self.cooldown <= .06) & has
        turn = t.where(has, turn, 0); thrust = t.where(has, thrust, 0); strafe = t.where(has, strafe, 0)
        # Return categorical action indices for consistency with PPO records.
        return t.stack((turn + 1, thrust + 1, strafe + 1, fire.long()), dim=-1)

    def _physics_tick(self, acts, tick_active):
        t, e, dt = self.t, self.e, self.e.DT
        tick_active = tick_active & self.active_env
        active_ships = self.alive & tick_active[:, None]
        self.sim_time += tick_active.float() * dt
        self.step_count += tick_active.long()
        turn = acts[:, :, 0].float() - 1.0
        thrust = acts[:, :, 1].float() - 1.0
        strafe = acts[:, :, 2].float() - 1.0
        fire = acts[:, :, 3] > 0
        self.heading = self._angle(self.heading + turn * e.TURN_RATE * dt * active_ships.float())
        fx, fy = t.cos(self.heading), t.sin(self.heading)
        lx, ly = -fy, fx
        self.vx = self.vx + (fx * thrust * e.ACCEL_FORWARD + lx * strafe * e.ACCEL_STRAFE) * dt * active_ships.float()
        self.vy = self.vy + (fy * thrust * e.ACCEL_FORWARD + ly * strafe * e.ACCEL_STRAFE) * dt * active_ships.float()
        drag = math.exp(-e.DRAG * dt)
        vx_new, vy_new = self.vx * drag, self.vy * drag
        speed = t.sqrt(vx_new * vx_new + vy_new * vy_new).clamp_min(1e-6)
        scale = t.clamp(e.MAX_SPEED / speed, max=1.0)
        self.vx = t.where(active_ships, vx_new * scale, self.vx)
        self.vy = t.where(active_ships, vy_new * scale, self.vy)
        self.x = t.where(active_ships, t.remainder(self.x + self.vx * dt, e.WORLD_W), self.x)
        self.y = t.where(active_ships, t.remainder(self.y + self.vy * dt, e.WORLD_H), self.y)
        self.cooldown = t.where(active_ships, (self.cooldown - dt).clamp_min(0), self.cooldown)
        regen = active_ships & (self.shield < e.MAX_SHIELD) & ((self.sim_time[:, None] - self.last_hit_time) > e.SHIELD_DELAY)
        self.shield = t.where(regen, (self.shield + e.SHIELD_REGEN * dt).clamp_max(e.MAX_SHIELD), self.shield)
        # Allocate simultaneous shots to distinct free projectile slots by ranks.
        can_fire = active_ships & fire & (self.cooldown <= 1e-6)
        free_slots = ~self.balive
        free_count = free_slots.sum(dim=1)
        bidx = t.arange(self.B, device=self.dev).view(1, self.B).expand(self.E, self.B)
        free_sorted = t.topk(t.where(free_slots, bidx, self.B), k=self.S, dim=1, largest=False).values
        fire_rank = can_fire.long().cumsum(dim=1) - 1
        slot_idx = free_sorted.gather(1, fire_rank.clamp_min(0))
        has_room = fire_rank < free_count[:, None]
        can_fire = can_fire & has_room & (slot_idx < self.B)
        rows, cols = t.where(can_fire)
        if rows.numel() > 0:
            slots = slot_idx[rows, cols]
            self.bx[rows, slots] = t.remainder(self.x[rows, cols] + fx[rows, cols] * (e.SHIP_RADIUS + 4), e.WORLD_W)
            self.by[rows, slots] = t.remainder(self.y[rows, cols] + fy[rows, cols] * (e.SHIP_RADIUS + 4), e.WORLD_H)
            self.bvx[rows, slots] = self.vx[rows, cols] + fx[rows, cols] * e.BULLET_SPEED
            self.bvy[rows, slots] = self.vy[rows, cols] + fy[rows, cols] * e.BULLET_SPEED
            self.bteam[rows, slots] = self.team[rows, cols]
            self.bowner[rows, slots] = cols
            self.bttl[rows, slots] = e.BULLET_TTL
            self.balive[rows, slots] = True
            self.shots[rows, cols] += 1.0
            self.cooldown[rows, cols] = e.FIRE_COOLDOWN
        active_bullets = self.balive & tick_active[:, None]
        self.bx = t.where(active_bullets, t.remainder(self.bx + self.bvx * dt, e.WORLD_W), self.bx)
        self.by = t.where(active_bullets, t.remainder(self.by + self.bvy * dt, e.WORLD_H), self.by)
        self.bttl = t.where(active_bullets, self.bttl - dt, self.bttl)
        self.balive = self.balive & (self.bttl > 0)
        # Simultaneous projectile/ship collision using [arena, bullet, ship] tensors.
        cdx = self._wrap(self.x[:, None, :] - self.bx[:, :, None], e.WORLD_W)
        cdy = self._wrap(self.y[:, None, :] - self.by[:, :, None], e.WORLD_H)
        d2 = cdx * cdx + cdy * cdy
        slot_ids = t.arange(self.S, device=self.dev).view(1, 1, self.S)
        eligible = (self.alive[:, None, :] & tick_active[:, None, None] & self.balive[:, :, None] &
                    (self.team[:, None, :] != self.bteam[:, :, None]) & (slot_ids != self.bowner[:, :, None]))
        hit_matrix = eligible & (d2 <= (e.SHIP_RADIUS + e.BULLET_RADIUS) ** 2)
        hit_any = hit_matrix.any(dim=-1)
        hit_ship_idx = t.where(hit_matrix, d2, t.full_like(d2, float("inf"))).argmin(dim=-1)
        per_ship_damage = t.zeros((self.E, self.S), dtype=t.float32, device=self.dev)
        per_ship_damage.scatter_add_(1, hit_ship_idx, hit_any.float() * e.BULLET_DAMAGE)
        had_damage = per_ship_damage > 0
        old_alive = self.alive.clone()
        shield_damage = t.minimum(self.shield, per_ship_damage)
        self.shield = (self.shield - shield_damage).clamp_min(0)
        self.hp = self.hp - (per_ship_damage - shield_damage)
        self.damage_taken += per_ship_damage
        self.last_hit_time = t.where(had_damage, self.sim_time[:, None], self.last_hit_time)
        # Attribute damage to projectile owners.
        owner_damage = t.zeros((self.E, self.S), dtype=t.float32, device=self.dev)
        owner_valid = hit_any & (self.bowner >= 0)
        owner_damage.scatter_add_(1, self.bowner.clamp_min(0), owner_valid.float() * e.BULLET_DAMAGE)
        self.damage_dealt += owner_damage
        self.balive = self.balive & ~hit_any
        just_dead = self.alive & (self.hp <= 0) & tick_active[:, None]
        self.hp = t.where(just_dead, t.zeros_like(self.hp), self.hp)
        self.alive = self.alive & ~just_dead
        self.deaths += just_dead.float()
        # Kill credit: assign each newly dead ship to the first projectile that hit it this tick.
        if True:
            hit_by_target = hit_matrix.permute(0, 2, 1)  # [E,S,B]
            b_ids = t.arange(self.B, device=self.dev).view(1, 1, self.B).expand(self.E, self.S, self.B)
            first_b = t.where(hit_by_target, b_ids, self.B).amin(dim=-1).clamp(max=self.B - 1)
            owner_for_ship = t.gather(self.bowner, 1, first_b)
            credit_mask = just_dead & (owner_for_ship >= 0)
            self.kills.scatter_add_(1, owner_for_ship.clamp_min(0), credit_mask.float())
        # Episode stops when one side has no ships left; later ticks do no work for it.
        blue_live = ((self.team == 0) & self.alive).sum(dim=1)
        red_live = ((self.team == 1) & self.alive).sum(dim=1)
        eliminated = (blue_live == 0) | (red_live == 0)
        self.active_env = self.active_env & ~eliminated

    def collect(self, stop_event=None):
        t, e = self.t, self.e
        E, S = self.E, self.S
        obs_buf, action_buf, logp_buf, value_buf = [], [], [], []
        reward_buf, valid_buf, done_buf = [], [], []
        rollout_start = time.perf_counter()
        device = str(self.dev)
        cuda_start = cuda_end = None
        if self.dev.type == "cuda":
            try:
                cuda_start = t.cuda.Event(enable_timing=True)
                cuda_end = t.cuda.Event(enable_timing=True)
                cuda_start.record()
            except Exception:
                cuda_start = cuda_end = None
        self.policy.last_device = f"GPU vector rollout / {device} / {self.E} arenas"
        self.policy.last_inference_backend = "CUDA / vectorized battles"
        for decision in range(self.max_decisions):
            if stop_event is not None and stop_event.is_set():
                self.active_env[:] = False
                break
            # Checking a CUDA tensor in a Python `if` forces a device sync. Poll
            # less frequently: checking every 32 decisions substantially reduces
            # host/device barriers in long vectorized batches. Inactive arenas are
            # masked, so the occasional overshoot is harmless.
            if decision % 32 == 0 and not bool(self.active_env.any()):
                break
            valid = self.alive & self.active_env[:, None]
            obs = self._observe()
            # Both teams contribute records in self-play; otherwise only blue is trained.
            if self.opponent_mode == "selfplay":
                train_mask = valid
            else:
                train_mask = valid & (self.team == 0)
            acts, logp, values = self._policy_sample(obs)
            if self.opponent_mode != "selfplay":
                heuristic = self._heuristic_actions()
                acts = t.where((self.team == 1)[:, :, None], heuristic, acts)
            before_alive = self.alive.clone()
            before_damage_dealt = self.damage_dealt.clone()
            before_damage_taken = self.damage_taken.clone()
            before_kills = self.kills.clone()
            before_shots = self.shots.clone()
            aim0, distance0 = self._aim()
            # `acts` remains categorical: 0/1/2 map to -1/0/+1 inside
            # _physics_tick. Subtracting here as well would shift every action
            # twice (and largely disable forward thrust and positive turning).
            self.last_turn = t.where(valid, acts[:, :, 0].float() - 1.0, self.last_turn)
            for _ in range(e.ACTION_REPEAT):
                self._physics_tick(acts, self.active_env.clone())
                # Inactive environments are masked in _physics_tick; others continue.
            died = before_alive & ~self.alive
            blue_dead = ((died) & (self.team == 0)).sum(dim=1).float()
            red_dead = ((died) & (self.team == 1)).sum(dim=1).float()
            d_dealt = self.damage_dealt - before_damage_dealt
            d_taken = self.damage_taken - before_damage_taken
            d_kills = self.kills - before_kills
            d_shots = self.shots - before_shots
            aim1, distance1 = self._aim()
            range_factor = t.clamp((1000.0 - distance0) / 800.0, 0, 1)
            range_after = t.clamp((1000.0 - distance1) / 800.0, 0, 1)
            # Keep reward semantics aligned with Stage 6.12 optimized backend so this
            # historical physics implementation remains a meaningful parity reference.
            reward = (e.REWARD_DAMAGE_DEALT * d_dealt - e.REWARD_DAMAGE_TAKEN * d_taken
                      + e.REWARD_PER_KILL * d_kills - e.REWARD_DEATH * died.float())
            enemy_dead = t.where(self.team == 0, red_dead[:, None], blue_dead[:, None])
            ally_dead = t.where(self.team == 0, blue_dead[:, None], red_dead[:, None])
            reward = reward + 1.8 * enemy_dead - 2.4 * ally_dead
            reward = reward + .065 * (aim1 - aim0)
            reward = reward + .010 * (aim1.clamp_min(0) ** 2) * range_after
            finite_dist = t.isfinite(distance0) & t.isfinite(distance1)
            desired_range = 480.0
            before_p = (distance0 - desired_range).abs()
            after_p = (distance1 - desired_range).abs()
            reward += .016 * t.clamp((before_p - after_p) / 30.0, -1, 1) * finite_dist.float()
            shot_signal = (e.REWARD_SHOT_AIM_BONUS * (aim0.clamp_min(0) ** 2)
                           * range_factor - e.REWARD_SHOT_BASE_COST)
            reward += d_shots * shot_signal
            reward -= e.REWARD_STEP_COST
            reward = t.where(train_mask, reward, t.zeros_like(reward))
            # Environment ends by elimination or at horizon. Mark each last valid record terminal.
            ended_now = ~self.active_env
            horizon = decision == self.max_decisions - 1
            if horizon:
                ended_now = ended_now | self.active_env
                self.active_env[:] = False
            done = died | ended_now[:, None]
            obs_buf.append(obs.detach())
            action_buf.append(acts.detach())
            logp_buf.append(logp.detach())
            value_buf.append(values.detach())
            reward_buf.append(reward.detach())
            valid_buf.append(train_mask.detach())
            done_buf.append(done.detach())
        if not obs_buf:
            return []
        # Terminal score mirrors the scalar Arena rollout objective.
        blue_alive = ((self.team == 0) & self.alive).sum(dim=1).float()
        red_alive = ((self.team == 1) & self.alive).sum(dim=1).float()
        blue_kills = (self.kills * (self.team == 0).float()).sum(dim=1)
        red_kills = (self.kills * (self.team == 1).float()).sum(dim=1)
        blue_damage = (self.damage_dealt * (self.team == 0).float()).sum(dim=1)
        red_damage = (self.damage_dealt * (self.team == 1).float()).sum(dim=1)
        blue_survivors, red_survivors = blue_alive.clone(), red_alive.clone()
        outcome = t.where((blue_alive > 0) & (red_alive == 0), 0,
                          t.where((blue_alive == 0) & (red_alive > 0), 1, -1))
        terminal_blue = (blue_kills - red_kills) * 8.0 + (blue_alive - red_alive) * 6.0 + t.clamp((blue_damage - red_damage) / 65.0, -3, 3) - 1.5
        terminal_red = (red_kills - blue_kills) * 8.0 + (red_alive - blue_alive) * 6.0 + t.clamp((red_damage - blue_damage) / 65.0, -3, 3) - 1.5
        terminal_blue = t.where(outcome == 0, 24.0, t.where(outcome == 1, -24.0, terminal_blue))
        terminal_red = t.where(outcome == 1, 24.0, t.where(outcome == 0, -24.0, terminal_red))
        # Add terminal objective to the last reward in each env/team trajectory.
        rewards = t.stack(reward_buf, dim=0).clone()  # T,E,S
        valid_t = t.stack(valid_buf, dim=0)
        dones_t = t.stack(done_buf, dim=0).clone()
        obs_t = t.stack(obs_buf, dim=0)
        act_t = t.stack(action_buf, dim=0)
        logp_t = t.stack(logp_buf, dim=0)
        value_t = t.stack(value_buf, dim=0)
        T = rewards.shape[0]
        time_axis = t.arange(T, device=self.dev).view(T, 1, 1).expand(T, E, S)
        last_t_by_ship = t.where(valid_t, time_axis, -1).amax(dim=0)  # [E,S], -1 if no records
        for env_i in range(E):
            for team_i, terminal in ((0, terminal_blue[env_i]), (1, terminal_red[env_i])):
                team_slots = (self.team[env_i] == team_i) & (last_t_by_ship[env_i] >= 0)
                ship_indices = t.where(team_slots)[0]
                if ship_indices.numel() == 0:
                    continue
                last_indices = last_t_by_ship[env_i, ship_indices]
                counts = self.blue_counts[env_i] if team_i == 0 else self.red_counts[env_i]
                rewards[last_indices, env_i, ship_indices] += terminal / max(1, int(counts))
                dones_t[last_indices, env_i, ship_indices] = True
        # Batched GAE over time; done/invalid boundaries prevent leakage across ships.
        adv_t = t.zeros_like(rewards)
        gae = t.zeros((E, S), dtype=t.float32, device=self.dev)
        gamma, lam = .993, .94
        for ti in range(T - 1, -1, -1):
            if ti + 1 < T:
                next_valid = valid_t[ti + 1]
                next_value = value_t[ti + 1]
            else:
                next_valid = t.zeros((E, S), dtype=t.bool, device=self.dev)
                next_value = t.zeros((E, S), dtype=t.float32, device=self.dev)
            nonterminal = (~dones_t[ti]) & next_valid
            delta = rewards[ti] + gamma * next_value * nonterminal.float() - value_t[ti]
            gae = delta + gamma * lam * nonterminal.float() * gae
            gae = t.where(valid_t[ti], gae, t.zeros_like(gae))
            adv_t[ti] = gae
        ret_t = adv_t + value_t
        # Collect episode summaries on-device; put all CUDA->CPU copies on the queue
        # and synchronize only once. Repeated pageable .cpu().numpy() calls can create
        # multiple host/device barriers and inflate wall time when the model is large.
        blue_mask_f = (self.team == 0).float()
        red_mask_f = (self.team == 1).float()
        summary_tensor = t.stack((
            (self.shots * blue_mask_f).sum(dim=1),
            (self.shots * red_mask_f).sum(dim=1),
            blue_damage, red_damage, blue_kills, red_kills,
            blue_survivors, red_survivors, outcome.float(), self.step_count.float(),
        ), dim=1)
        if cuda_end is not None:
            try:
                cuda_end.record()
            except Exception:
                cuda_end = None

        tensors_for_host = (valid_t, obs_t, act_t, logp_t, value_t, rewards,
                            dones_t, adv_t, ret_t, summary_tensor)
        if self.dev.type == "cuda":
            host_buffers = []
            for src in tensors_for_host:
                host = t.empty(src.shape, dtype=src.dtype, device="cpu", pin_memory=True)
                host.copy_(src, non_blocking=True)
                host_buffers.append(host)
            t.cuda.synchronize(self.dev)
            (valid_cpu, obs_cpu, act_cpu, logp_cpu, value_cpu, reward_cpu,
             done_cpu, adv_cpu, ret_cpu, summary_cpu) = host_buffers
            if cuda_start is not None and cuda_end is not None:
                try:
                    self.last_cuda_device_seconds = float(cuda_start.elapsed_time(cuda_end)) / 1000.0
                except Exception:
                    self.last_cuda_device_seconds = 0.0
        else:
            (valid_cpu, obs_cpu, act_cpu, logp_cpu, value_cpu, reward_cpu,
             done_cpu, adv_cpu, ret_cpu, summary_cpu) = tensors_for_host
            self.last_cuda_device_seconds = 0.0
        valid_np = valid_cpu.numpy()
        obs_np = obs_cpu.numpy()
        act_np = act_cpu.numpy()
        logp_np = logp_cpu.numpy()
        value_np = value_cpu.numpy()
        reward_np = reward_cpu.numpy()
        done_np = done_cpu.numpy()
        adv_np = adv_cpu.numpy()
        ret_np = ret_cpu.numpy()
        summary_np = summary_cpu.numpy()
        reward_slots = slice(None) if self.opponent_mode == "selfplay" else slice(0, 5)
        episode_reward_np = reward_np[:, :, reward_slots].sum(axis=(0, 2))
        results = []
        for env_i in range(E):
            # Pack each arena's valid rows as contiguous arrays. A dict per ship-step
            # created hundreds of thousands of Python objects and delayed PPO on CPU.
            mask = valid_np[:, env_i, :]
            packed = self.e.PackedExperience(
                obs_np[:, env_i][mask].astype(np.float32, copy=True),
                act_np[:, env_i][mask].astype(np.int64, copy=True),
                logp_np[:, env_i][mask].astype(np.float32, copy=True),
                value_np[:, env_i][mask].astype(np.float32, copy=True),
                reward_np[:, env_i][mask].astype(np.float32, copy=True),
                done_np[:, env_i][mask].astype(np.bool_, copy=True),
                adv_np[:, env_i][mask].astype(np.float32, copy=True),
                ret_np[:, env_i][mask].astype(np.float32, copy=True),
            )
            (bshots, rshots, bdamage, rdamage, bkills, rkills,
             bs, rs, outv_f, steps_f) = summary_np[env_i]
            bshots, rshots = float(bshots), float(rshots)
            bdamage, rdamage = float(bdamage), float(rdamage)
            bkills, rkills = float(bkills), float(rkills)
            bs, rs = int(bs), int(rs)
            outv = int(outv_f)
            out = None if outv < 0 else outv
            ep_reward = float(episode_reward_np[env_i])
            metrics = {
                "blue_damage": bdamage, "red_damage": rdamage,
                "blue_shots": bshots, "red_shots": rshots,
                "blue_kills": bkills, "red_kills": rkills,
                "blue_survivors": bs, "red_survivors": rs,
                "blue_hit_rate": min(1.0, bdamage / max(1.0, bshots * e.BULLET_DAMAGE)),
                "red_hit_rate": min(1.0, rdamage / max(1.0, rshots * e.BULLET_DAMAGE)),
                "rollout_backend": "GPU tensor physics",
            }
            results.append((packed, ep_reward, out, int(self.blue_counts[env_i]),
                            int(self.red_counts[env_i]), int(round(float(steps_f))), metrics))
        self.last_collect_wall_seconds = max(0.001, time.perf_counter() - rollout_start)
        return results
