@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if errorlevel 1 goto bad_dir
set "GRAVITRUEX_GPU_FAST=1"
set "GRAVITRUEX_CUDA_GRAPH=1"
set "PYTHONUTF8=1"
if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
  goto run_test
)
where py >nul 2>&1
if not errorlevel 1 (
  set "PY=py -3"
  goto run_test
)
where python >nul 2>&1
if not errorlevel 1 (
  set "PY=python"
  goto run_test
)
echo Python not found. Run run_gravitruex.bat once first.
pause
exit /b 1
:run_test
echo Running CUDA Graph diagnostic. Output will be saved.
call %PY% tests\test_cuda_graph_cuda.py > cuda_graph_capture_diagnostic.txt 2>&1
set "RC=%ERRORLEVEL%"
type cuda_graph_capture_diagnostic.txt
echo.
echo Diagnostic exit code: %RC%
echo Log: %CD%\cuda_graph_capture_diagnostic.txt
pause
exit /b %RC%
:bad_dir
echo Could not switch to application directory.
pause
exit /b 1
