@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if errorlevel 1 goto bad_dir

if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
) else (
  where py >nul 2>&1
  if not errorlevel 1 (
    set "PY=py -3"
  ) else (
    set "PY=python"
  )
)

echo This test performs no PPO updates and does not save or modify weights.
echo It compares eager dispatch and CUDA Graph replay across GPU batch sizes.
echo Default sizes: 64,128,256,384,512,768,1024; 2 repeats each.
echo The first graph capture can take extra time; later measurements exclude capture time.
echo.
call %PY% bench_gpu_fast_stage6.py
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Benchmark failed or CUDA was unavailable. Error code: %RC%
pause
exit /b %RC%

:bad_dir
echo Could not switch to application directory.
pause
exit /b 1
