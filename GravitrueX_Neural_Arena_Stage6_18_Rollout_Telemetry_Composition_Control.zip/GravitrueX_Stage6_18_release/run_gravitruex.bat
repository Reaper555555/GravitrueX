@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if errorlevel 1 goto bad_dir

rem Stage 6.17: neural policies in visible combat require CUDA; no CPU-only launcher mode.
set "BACKEND=CUDA"
set "GRAVITRUEX_FORCE_CPU=0"
echo.
echo Stage 6.17 requires CUDA for visible neural combat.
echo The arena will pause and show an error instead of silently running neural inference on CPU.

echo.
echo Selected backend: %BACKEND%
rem Avoid each rollout worker spawning a full BLAS thread pool.
set "OMP_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"

set "PYBASE="
if exist ".venv\Scripts\python.exe" goto use_venv
where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYBASE=py -3"
)
if not defined PYBASE (
    where python >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
        if not errorlevel 1 set "PYBASE=python"
    )
)
if not defined PYBASE goto no_python

echo Creating the isolated Python environment if needed...
call %PYBASE% -m venv .venv
if errorlevel 1 goto venv_failed

:use_venv
set "PY=%CD%\.venv\Scripts\python.exe"
"%PY%" -m pip --version >nul 2>&1
if errorlevel 1 goto pip_missing

"%PY%" -c "import numpy" >nul 2>&1
if errorlevel 1 (
    echo Installing NumPy...
    "%PY%" -m pip install "numpy>=1.24"
    if errorlevel 1 goto dependency_failed
)
"%PY%" -c "import psutil" >nul 2>&1
if errorlevel 1 (
    echo Installing optional resource monitor...
    "%PY%" -m pip install "psutil>=5.9"
)

rem Preserve a working CUDA installation, otherwise install the cu128 build.
"%PY%" -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" >nul 2>&1
if not errorlevel 1 goto launch

echo Installing CUDA-enabled PyTorch 2.11.0. This download is large...
"%PY%" -m pip install --upgrade --force-reinstall "torch==2.11.0" --index-url https://download.pytorch.org/whl/cu128
if errorlevel 1 goto cuda_fallback_prompt
"%PY%" -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" >nul 2>&1
if not errorlevel 1 goto launch

:cuda_fallback_prompt
echo CUDA did not become available.
echo Stage 6.17 cannot launch visible neural combat without CUDA-enabled PyTorch.
echo Check NVIDIA drivers, Python compatibility, and the CUDA-enabled PyTorch install.
pause
goto torch_failed

:launch
echo.
echo Launching GravitrueX Neural Arena...
"%PY%" -u gravitruex_ai.py
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" (
    echo.
    echo GravitrueX exited with error code %APP_EXIT%.
    pause
)
exit /b %APP_EXIT%

:no_python
echo Python 3.10 or newer with Tcl/Tk is required.
echo Install Python from https://www.python.org/downloads/windows/ and enable Tcl/Tk.
pause
exit /b 1
:venv_failed
echo Could not create the local Python environment.
pause
exit /b 1
:pip_missing
echo pip is unavailable in this Python environment.
pause
exit /b 1
:dependency_failed
echo Could not install NumPy. Check internet connection and disk space.
pause
exit /b 1
:torch_failed
echo Could not install CUDA-enabled PyTorch. Check internet connection, NVIDIA drivers, and Python compatibility.
pause
exit /b 1
:bad_dir
echo Could not switch to the application directory.
pause
exit /b 1
