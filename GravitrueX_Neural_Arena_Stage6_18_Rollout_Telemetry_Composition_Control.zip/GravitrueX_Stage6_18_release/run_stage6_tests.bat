@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if errorlevel 1 goto bad_dir

set "PY_COMMAND="
if exist ".venv\Scripts\python.exe" (
  set "PY_COMMAND=.venv\Scripts\python.exe"
  goto run_tests
)
where py >nul 2>&1
if not errorlevel 1 (
  set "PY_COMMAND=py -3"
  goto run_tests
)
where python >nul 2>&1
if not errorlevel 1 (
  set "PY_COMMAND=python"
  goto run_tests
)
echo Python 3.10+ was not found. Run run_gravitruex.bat once first.
pause
exit /b 1

:run_tests
echo.
echo ==== 1/22: application self-test ====
call %PY_COMMAND% gravitruex_ai.py --self-test
if errorlevel 1 goto failed

echo.
echo ==== 2/22: vector physics, finite values and state snapshot ====
call %PY_COMMAND% dev\run_physics_tests.py
if errorlevel 1 goto failed

echo.
echo ==== 3/22: Stage 4 vs optimized rollout, heuristic mode ====
call %PY_COMMAND% dev\compare.py gravitruex_gpu_batch_stage4_original.py gravitruex_gpu_batch.py --count 4 --decisions 24 --mode heuristic
if errorlevel 1 goto failed

echo.
echo ==== 4/22: Stage 4 vs optimized rollout, self-play mode ====
call %PY_COMMAND% dev\compare.py gravitruex_gpu_batch_stage4_original.py gravitruex_gpu_batch.py --count 4 --decisions 24 --mode selfplay
if errorlevel 1 goto failed

echo.
echo ==== 5/22: GPU-only route/accounting regression (CPU stub) ====
call %PY_COMMAND% tests\test_gpu_only_dispatch.py
if errorlevel 1 goto failed

echo.
echo ==== 6/22: hybrid CPU+tensor orchestration (CPU stub) ====
call %PY_COMMAND% tests\test_hybrid_orchestration_cpu_backend.py
if errorlevel 1 goto failed

echo.
echo ==== 7/22: comparison must reject NaN/Inf ====
call %PY_COMMAND% tests\test_compare_nonfinite_guard.py
if errorlevel 1 goto failed

echo.
echo ==== 8/22: end-to-end CPU training smoke (temporary model; does not touch your weights) ====
call %PY_COMMAND% tests\test_training_cpu_smoke.py
if errorlevel 1 goto failed

echo.
echo ==== 9/22: GPU rollout record budget follows actual ship composition ====
call %PY_COMMAND% tests\test_gpu_record_budget.py
if errorlevel 1 goto failed

echo.
echo ==== 10/22: Training failure recovery and crash-report regression ====
call %PY_COMMAND% tests\test_training_failure_recovery.py
if errorlevel 1 goto failed

echo.
echo ==== 11/22: Hybrid CPU/GPU resource limits and RAM guard ====
call %PY_COMMAND% tests\test_hybrid_resource_limits.py
if errorlevel 1 goto failed

echo.
echo ==== 12/22: Hybrid async cutoff + no-yield auto backoff ====
call %PY_COMMAND% tests\test_hybrid_async_cutoff.py
if errorlevel 1 goto failed

echo.
echo ==== 13/22: config round-trip, 4096-arena limit, OOM fallback, strict CPU cap ====
call %PY_COMMAND% tests\test_config_gpu_batch_limits.py
if errorlevel 1 goto failed

echo.
echo ==== 14/22: Heuristic imitation labels + auxiliary PPO loss ====
call %PY_COMMAND% tests\test_teacher_imitation.py
if errorlevel 1 goto failed

echo.
echo ==== 15/22: fire-window floor, targeting/dodge priors, strict GPU battle ====
call %PY_COMMAND% tests\test_fire_prior_gpu_battle.py
if errorlevel 1 goto failed

echo.
echo ==== 16/22: CUDA Graph preflight on 2, 64, 256 arenas ====
call %PY_COMMAND% tests\test_cuda_graph_cuda.py
if errorlevel 1 goto failed

echo.
echo ==== 17/22: Main header tabs, battle/training panel switch and first-frame render ====
call %PY_COMMAND% tests\check_ui_layout_smoke.py
if errorlevel 1 goto failed

echo.
echo ==== 18/22: desktop diagnostic snapshot overwrite + throughput semantics ====
call %PY_COMMAND% tests\test_desktop_diagnostics_snapshot.py
if errorlevel 1 goto failed

echo.
echo ==== 19/22: Training team size / actual GPU arenas / separate CPU and GPU timing ====
call %PY_COMMAND% tests\test_training_composition_and_telemetry.py
if errorlevel 1 goto failed

echo.
echo ==== 20/22: battle HP/shield bars ====
call %PY_COMMAND% tests\test_battle_hp_shield_hud.py
if errorlevel 1 goto failed

echo.
echo ==== 21/22: Built-in model variants + checkpoint identity + PPO updates ====
call %PY_COMMAND% tests\test_model_variants.py
if errorlevel 1 goto failed

echo.
echo ==== 22/22: Adjustable visible battle horizon ====
call %PY_COMMAND% tests\test_visible_battle_horizon.py
if errorlevel 1 goto failed

echo ALL STAGE 6.18 MAIN-APP TESTS FINISHED. CUDA tests are skipped only when CUDA is unavailable.
pause
exit /b 0

:failed
echo.
echo TEST FAILURE: stage returned error code %ERRORLEVEL%.
echo Save this console output or send a screenshot/report.
pause
exit /b 1

:bad_dir
echo Could not switch to application directory.
pause
exit /b 1
